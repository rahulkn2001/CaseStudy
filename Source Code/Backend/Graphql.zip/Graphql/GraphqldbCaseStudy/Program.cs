using GraphqldbCaseStudy.Models;
using GraphqldbCaseStudy.Types;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContextFactory<RetailWebApplicationContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services
    .AddGraphQLServer()
    .AddQueryType<Query>()
    .AddType<AddressType>()
    .AddType<CartItemType>()
    .AddType<CartType>()
    .AddType<CategoryType>()
    .AddType<InventoryType>()
    .AddType<NotificationType>()
    .AddType<OrderItemType>()
    .AddType<OrderTableType>()
    .AddType<PaymentType>()
    .AddType<ProductType>()
    .AddType<ShipmentType>()
    .AddType<UsertableType>()
    .AddType<WishlistItemType>()
    .AddType<WishlistType>()
    .AddFiltering()
    .AddSorting()
    .AddProjections();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseRouting();

app.UseEndpoints(endpoints =>
{
    endpoints.MapGraphQL();
});



app.UseAuthorization();

app.MapControllers();

app.Run();
