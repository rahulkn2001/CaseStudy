﻿using GraphqldbCaseStudy.Models;

namespace GraphqldbCaseStudy.Types
{
    public class WishlistType : ObjectType<Wishlist>
    {
        protected override void Configure(IObjectTypeDescriptor<Wishlist> descriptor)
        {
            descriptor.Field(w => w.WishlistId).Type<NonNullType<IntType>>();
            descriptor.Field(w => w.UserId).Type<IntType>();
            descriptor.Field(w => w.User).Type<UsertableType>();
            descriptor.Field(w => w.WishlistItems).Type<ListType<WishlistItemType>>();
        }
    }
}
