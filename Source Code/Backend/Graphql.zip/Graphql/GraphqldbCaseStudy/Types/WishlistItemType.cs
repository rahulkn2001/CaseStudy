﻿using GraphqldbCaseStudy.Models;

namespace GraphqldbCaseStudy.Types
{
    public class WishlistItemType : ObjectType<WishlistItem>
    {
        protected override void Configure(IObjectTypeDescriptor<WishlistItem> descriptor)
        {
            descriptor.Field(wi => wi.WishlistItemId).Type<NonNullType<IntType>>();
            descriptor.Field(wi => wi.WishlistId).Type<IntType>();
            descriptor.Field(wi => wi.ProductId).Type<IntType>();
            descriptor.Field(wi => wi.Product).Type<ProductType>();
            descriptor.Field(wi => wi.Wishlist).Type<WishlistType>();
        }
    }
}
