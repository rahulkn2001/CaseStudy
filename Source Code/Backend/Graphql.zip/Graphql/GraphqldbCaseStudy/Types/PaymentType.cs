﻿using GraphqldbCaseStudy.Models;

namespace GraphqldbCaseStudy.Types
{
    public class PaymentType : ObjectType<Payment>
    {
        protected override void Configure(IObjectTypeDescriptor<Payment> descriptor)
        {
            descriptor.Field(p => p.PaymentId).Type<NonNullType<IntType>>();
            descriptor.Field(p => p.OrderId).Type<IntType>();
            descriptor.Field(p => p.Amount).Type<DecimalType>();
            descriptor.Field(p => p.PaymentDate).Type<DateTimeType>();
            descriptor.Field(p => p.PaymentMethod).Type<StringType>();
            descriptor.Field(p => p.Order).Type<OrderTableType>();
        }
    }
}
