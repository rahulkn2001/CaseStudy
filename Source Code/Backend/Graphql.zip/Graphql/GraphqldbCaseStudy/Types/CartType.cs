﻿using GraphqldbCaseStudy.Models;

namespace GraphqldbCaseStudy.Types
{
    public class CartType : ObjectType<Cart>
    {
        protected override void Configure(IObjectTypeDescriptor<Cart> descriptor)
        {
            descriptor.Field(c => c.CartId).Type<NonNullType<IntType>>();
            descriptor.Field(c => c.UserId).Type<IntType>();
            descriptor.Field(c => c.CartItems).Type<ListType<CartItemType>>();
            descriptor.Field(c => c.User).Type<UsertableType>();
        }
    }
}
