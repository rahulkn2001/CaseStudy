﻿using GraphqldbCaseStudy.Models;

namespace GraphqldbCaseStudy.Types
{
    public class NotificationType : ObjectType<Notification>
    {
        protected override void Configure(IObjectTypeDescriptor<Notification> descriptor)
        {
            descriptor.Field(n => n.NotificationId).Type<NonNullType<IntType>>();
            descriptor.Field(n => n.UserId).Type<IntType>();
            descriptor.Field(n => n.Message).Type<NonNullType<StringType>>();
            descriptor.Field(n => n.Date).Type<NonNullType<DateTimeType>>();
            descriptor.Field(n => n.User).Type<UsertableType>();
        }
    }
}
