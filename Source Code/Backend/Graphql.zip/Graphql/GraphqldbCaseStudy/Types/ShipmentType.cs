﻿using GraphqldbCaseStudy.Models;

namespace GraphqldbCaseStudy.Types
{
    public class ShipmentType : ObjectType<Shipment>
    {
        protected override void Configure(IObjectTypeDescriptor<Shipment> descriptor)
        {
            descriptor.Field(s => s.ShipmentId).Type<NonNullType<IntType>>();
            descriptor.Field(s => s.OrderId).Type<IntType>();
            descriptor.Field(s => s.ShipmentDate).Type<NonNullType<DateTimeType>>();
            descriptor.Field(s => s.TrackingNumber).Type<StringType>();
            descriptor.Field(s => s.Order).Type<OrderTableType>();
        }
    }
}
