﻿using GraphqldbCaseStudy.Models;

namespace GraphqldbCaseStudy.Types
{
    public class CategoryType : ObjectType<Category>
    {
        protected override void Configure(IObjectTypeDescriptor<Category> descriptor)
        {
            descriptor.Field(c => c.CategoryId).Type<NonNullType<IntType>>();
            descriptor.Field(c => c.CategoryName).Type<NonNullType<StringType>>();
            descriptor.Field(c => c.Products).Type<ListType<ProductType>>();
        }
    }
}
