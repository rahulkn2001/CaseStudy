﻿using GraphqldbCaseStudy.Models;

namespace GraphqldbCaseStudy.Types
{
    public class InventoryType : ObjectType<Inventory>
    {
        protected override void Configure(IObjectTypeDescriptor<Inventory> descriptor)
        {
            descriptor.Field(i => i.InventoryId).Type<NonNullType<IntType>>();
            descriptor.Field(i => i.StockQuantity).Type<NonNullType<IntType>>();
            descriptor.Field(i => i.RestockDate).Type<DateTimeType>();
            descriptor.Field(i => i.Product).Type<ProductType>();
        }
    }
}
