﻿using GraphqldbCaseStudy.Models;
using HotChocolate.Types;

namespace GraphqldbCaseStudy.Types
{
    public class OrderItemType : ObjectType<OrderItem>
    {
        protected override void Configure(IObjectTypeDescriptor<OrderItem> descriptor)
        {
            descriptor.Field(oi => oi.OrderItemId).Type<NonNullType<IntType>>();
            descriptor.Field(oi => oi.OrderId).Type<IntType>();
            descriptor.Field(oi => oi.ProductId).Type<IntType>();
            descriptor.Field(oi => oi.Quantity).Type<NonNullType<IntType>>();
            descriptor.Field(oi => oi.Price).Type<NonNullType<DecimalType>>();
            descriptor.Field(oi => oi.Order).Type<OrderTableType>();
            descriptor.Field(oi => oi.Product).Type<ProductType>();
        }
    }
}
