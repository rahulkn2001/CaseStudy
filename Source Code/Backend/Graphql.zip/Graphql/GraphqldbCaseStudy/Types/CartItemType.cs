﻿using GraphqldbCaseStudy.Models;

namespace GraphqldbCaseStudy.Types
{
    public class CartItemType : ObjectType<CartItem>
    {
        protected override void Configure(IObjectTypeDescriptor<CartItem> descriptor)
        {
            descriptor.Field(ci => ci.CartItemId).Type<NonNullType<IntType>>();
            descriptor.Field(ci => ci.CartId).Type<IntType>();
            descriptor.Field(ci => ci.ProductId).Type<IntType>();
            descriptor.Field(ci => ci.Quantity).Type<NonNullType<IntType>>();
            //descriptor.Field(ci => ci.Price).Type<NonNullType<DecimalType>>();
            descriptor.Field(ci => ci.Cart).Type<CartType>();
            descriptor.Field(ci => ci.Product).Type<ProductType>();
        }
    }
}
