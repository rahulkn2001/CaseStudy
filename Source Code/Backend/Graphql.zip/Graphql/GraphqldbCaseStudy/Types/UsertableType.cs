﻿using GraphqldbCaseStudy.Models;

namespace GraphqldbCaseStudy.Types
{
    public class UsertableType : ObjectType<Usertable>
    {
        protected override void Configure(IObjectTypeDescriptor<Usertable> descriptor)
        {
            descriptor.Field(u => u.UserId).Type<NonNullType<IntType>>();
            descriptor.Field(u => u.Firstname).Type<NonNullType<StringType>>();
            descriptor.Field(u => u.Lastname).Type<NonNullType<StringType>>();
            descriptor.Field(u => u.Email).Type<NonNullType<StringType>>();
            descriptor.Field(u => u.Addresses).Type<ListType<AddressType>>();
            descriptor.Field(u => u.Carts).Type<ListType<CartType>>();
            descriptor.Field(u => u.Notifications).Type<ListType<NotificationType>>();
            descriptor.Field(u => u.Ordertables).Type<ListType<OrderTableType>>();
            descriptor.Field(u => u.Wishlist).Type<WishlistType>();
        }
    }
}
