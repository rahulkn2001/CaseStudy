﻿//using GraphqldbCaseStudy.Models;

//namespace GraphqldbCaseStudy.Types
//{
//    public class Query
//    {
//        //Injecting dbcontext
//        private readonly RetailWebApplicationContext _context;
//        public Query(RetailWebApplicationContext context)
//        {
//            _context = context;
//        }

//        public IQueryable<Address> GetAddresses() => _context.Addresses.AsQueryable();
//        public Address GetAddress(int id) => _context.Addresses.Find(id);

//        // Cart Queries
//        public IQueryable<Cart> GetCarts() => _context.Carts.AsQueryable();
//        public Cart GetCart(int id) => _context.Carts.Find(id);

//        // CartItem Queries
//        public IQueryable<CartItem> GetCartItems() => _context.CartItems.AsQueryable();
//        public CartItem GetCartItem(int id) => _context.CartItems.Find(id);

//        // Category Queries
//        public IQueryable<Category> GetCategories() => _context.Categories.AsQueryable();
//        public Category GetCategory(int id) => _context.Categories.Find(id);

//        // Inventory Queries
//        public IQueryable<Inventory> GetInventories() => _context.Inventories.AsQueryable();
//        public Inventory GetInventory(int id) => _context.Inventories.Find(id);

//        // Notification Queries
//        public IQueryable<Notification> GetNotifications() => _context.Notifications.AsQueryable();
//        public Notification GetNotification(int id) => _context.Notifications.Find(id);

//        // Order Queries
//        public IQueryable<Ordertable> GetOrders() => _context.Ordertables.AsQueryable();
//        public Ordertable GetOrder(int id) => _context.Ordertables.Find(id);

//        // Payment Queries
//        public IQueryable<Payment> GetPayments() => _context.Payments.AsQueryable();
//        public Payment GetPayment(int id) => _context.Payments.Find(id);

//        // Product Queries
//        public IQueryable<Product> GetProducts() => _context.Products.AsQueryable();
//        public Product GetProduct(int id) => _context.Products.Find(id);

//        // Shipment Queries
//        public IQueryable<Shipment> GetShipments() => _context.Shipments.AsQueryable();
//        public Shipment GetShipment(int id) => _context.Shipments.Find(id);

//        // User Queries
//        public IQueryable<Usertable> GetUsers() => _context.Usertables.AsQueryable();
//        public Usertable GetUser(int id) => _context.Usertables.Find(id);

//        // Wishlist Queries
//        public IQueryable<Wishlist> GetWishlists() => _context.Wishlists.AsQueryable();
//        public Wishlist GetWishlist(int id) => _context.Wishlists.Find(id);

//        // WishlistItem Queries
//        public IQueryable<WishlistItem> GetWishlistItems() => _context.WishlistItems.AsQueryable();
//        public WishlistItem GetWishlistItem(int id) => _context.WishlistItems.Find(id);
//    }
//}


using GraphqldbCaseStudy.Models;

namespace GraphqldbCaseStudy.Types
{
    public class Query
    {
        //public IQueryable<Inventory> GetInventories([Service] RetailWebApplicationContext dbContext) => dbContext.Inventories;

        //public Inventory GetInventory(int id, [Service] RetailWebApplicationContext dbContext) =>
        //    dbContext.Inventories.FirstOrDefault(i => i.InventoryId == id);


        // Address Queries
        public IQueryable<Address> GetAddresses([Service] RetailWebApplicationContext dbContext) => dbContext.Addresses;
        public Address GetAddress(int id, [Service] RetailWebApplicationContext dbContext) =>
            dbContext.Addresses.FirstOrDefault(a => a.AddressId == id);

        // Cart Queries
        public IQueryable<Cart> GetCarts([Service] RetailWebApplicationContext dbContext) => dbContext.Carts;
        public Cart GetCart(int id, [Service] RetailWebApplicationContext dbContext) =>
            dbContext.Carts.FirstOrDefault(c => c.CartId == id);

        // CartItem Queries
        public IQueryable<CartItem> GetCartItems([Service] RetailWebApplicationContext dbContext) => dbContext.CartItems;
        public CartItem GetCartItem(int id, [Service] RetailWebApplicationContext dbContext) =>
            dbContext.CartItems.FirstOrDefault(ci => ci.CartItemId == id);

        // Category Queries
        public IQueryable<Category> GetCategories([Service] RetailWebApplicationContext dbContext) => dbContext.Categories;
        public Category GetCategory(int id, [Service] RetailWebApplicationContext dbContext) =>
            dbContext.Categories.FirstOrDefault(c => c.CategoryId == id);

        // Inventory Queries
        public IQueryable<Inventory> GetInventories([Service] RetailWebApplicationContext dbContext) => dbContext.Inventories;
        public Inventory GetInventory(int id, [Service] RetailWebApplicationContext dbContext) =>
            dbContext.Inventories.FirstOrDefault(i => i.InventoryId == id);

        // Notification Queries
        public IQueryable<Notification> GetNotifications([Service] RetailWebApplicationContext dbContext) => dbContext.Notifications;
        public Notification GetNotification(int id, [Service] RetailWebApplicationContext dbContext) =>
            dbContext.Notifications.FirstOrDefault(n => n.NotificationId == id);

        // Order Queries
        public IQueryable<Ordertable> GetOrders([Service] RetailWebApplicationContext dbContext) => dbContext.Ordertables;
        public Ordertable GetOrder(int id, [Service] RetailWebApplicationContext dbContext) =>
            dbContext.Ordertables.FirstOrDefault(o => o.OrderId == id);

        // Payment Queries
        public IQueryable<Payment> GetPayments([Service] RetailWebApplicationContext dbContext) => dbContext.Payments;
        public Payment GetPayment(int id, [Service] RetailWebApplicationContext dbContext) =>
            dbContext.Payments.FirstOrDefault(p => p.PaymentId == id);

        // Product Queries
        public IQueryable<Product> GetProducts([Service] RetailWebApplicationContext dbContext) => dbContext.Products;
        public Product GetProduct(int id, [Service] RetailWebApplicationContext dbContext) =>
            dbContext.Products.FirstOrDefault(p => p.ProductId == id);

        // Shipment Queries
        public IQueryable<Shipment> GetShipments([Service] RetailWebApplicationContext dbContext) => dbContext.Shipments;
        public Shipment GetShipment(int id, [Service] RetailWebApplicationContext dbContext) =>
            dbContext.Shipments.FirstOrDefault(s => s.ShipmentId == id);

        // User Queries
        public IQueryable<Usertable> GetUsers([Service] RetailWebApplicationContext dbContext) => dbContext.Usertables;
        public Usertable GetUser(int id, [Service] RetailWebApplicationContext dbContext) =>
            dbContext.Usertables.FirstOrDefault(u => u.UserId == id);

        // Wishlist Queries
        public IQueryable<Wishlist> GetWishlists([Service] RetailWebApplicationContext dbContext) => dbContext.Wishlists;
        public Wishlist GetWishlist(int id, [Service] RetailWebApplicationContext dbContext) =>
            dbContext.Wishlists.FirstOrDefault(w => w.WishlistId == id);

        // WishlistItem Queries
        public IQueryable<WishlistItem> GetWishlistItems([Service] RetailWebApplicationContext dbContext) => dbContext.WishlistItems;
        public WishlistItem GetWishlistItem(int id, [Service] RetailWebApplicationContext dbContext) =>
            dbContext.WishlistItems.FirstOrDefault(wi => wi.WishlistItemId == id);
    }
}



