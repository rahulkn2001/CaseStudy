﻿using GraphqldbCaseStudy.Models;

namespace GraphqldbCaseStudy.Types
{
    public class OrderTableType : ObjectType<Ordertable>
    {
        protected override void Configure(IObjectTypeDescriptor<Ordertable> descriptor)
        {
            descriptor.Field(o => o.OrderId).Type<NonNullType<IntType>>();
            descriptor.Field(o => o.UserId).Type<IntType>();
            descriptor.Field(o => o.OrderDate).Type<DateTimeType>();
            descriptor.Field(o => o.Status).Type<StringType>();
            descriptor.Field(o => o.OrderItems).Type<ListType<OrderItemType>>();
            descriptor.Field(o => o.Payment).Type<PaymentType>();
            descriptor.Field(o => o.Shipment).Type<ShipmentType>();
            descriptor.Field(o => o.User).Type<UsertableType>();
        }
    }
}
