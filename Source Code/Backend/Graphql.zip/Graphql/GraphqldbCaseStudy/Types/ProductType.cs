﻿using GraphqldbCaseStudy.Models;

namespace GraphqldbCaseStudy.Types
{
    public class ProductType : ObjectType<Product>
    {
        protected override void Configure(IObjectTypeDescriptor<Product> descriptor)
        {
            descriptor.Field(p => p.ProductId).Type<NonNullType<IntType>>();
            descriptor.Field(p => p.ProductName).Type<NonNullType<StringType>>();
            descriptor.Field(p => p.Price).Type<NonNullType<DecimalType>>();
            descriptor.Field(p => p.CategoryId).Type<IntType>();
            descriptor.Field(p => p.InventoryId).Type<IntType>();
            descriptor.Field(p => p.CartItems).Type<ListType<CartItemType>>();
            descriptor.Field(p => p.Category).Type<CategoryType>();
            descriptor.Field(p => p.Inventory).Type<InventoryType>();
            descriptor.Field(p => p.OrderItems).Type<ListType<OrderItemType>>();
            descriptor.Field(p => p.WishlistItems).Type<ListType<WishlistItemType>>();
        }
    }
}
