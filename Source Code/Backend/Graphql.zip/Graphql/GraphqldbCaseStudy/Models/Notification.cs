﻿using System;
using System.Collections.Generic;

namespace GraphqldbCaseStudy.Models;

public partial class Notification
{
    public int NotificationId { get; set; }

    public int? UserId { get; set; }

    public string Message { get; set; } = null!;

    public DateTime Date { get; set; }

    public virtual Usertable? User { get; set; }
}
