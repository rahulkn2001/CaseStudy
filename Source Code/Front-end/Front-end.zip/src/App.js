// App.jsx
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Homepage from './components/Homepage';
import Login from './components/login';
import Address from './components/Address';
import AddAddress from './components/AddAddress'
import Cart from './components/Cart';
import Orders from './components/Orders';
import Register from './components/register';
import ProtectedRoute from './components/Protectedroute';
import UpdateAddress from './components/Address'
import UserProfile from './components/UserProfile';
import Product from './components/Product';
import ProductByCategory from './components/ProductByCategory';
import Category from './components/Category';
import OrderHistory from './components/OrderHistory';
import Payment from './components/Payment';
import VoiceBot from './components/VoiceBot';
import Wishlist from './components/Wishlist';
import OrderConfirmation from './components/OrderConfirmation';
import VerifyOtp from './components/VerifyOtp';


import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';






const App = () => {
  const stripePromise = loadStripe('pk_test_51PxSvv09cWF7fLdvbv0QH7Jc4k2cVs6hdofElXjZ95pWKOIzDEGtt0ZSfX0pzfHMZvvmWSII9aKrMzaeNxBlsLdi00y5inCZXf');
  return (
    <Router>
      <ToastContainer
       position="bottom-center"
       />
      <Routes>
        <Route path='/register' element={<Register />} />
        <Route path="/" element={<Login />} />
        <Route path="/homepage" element={<ProtectedRoute><Homepage /></ProtectedRoute>} />
        <Route path="/address" element={<ProtectedRoute><Address /></ProtectedRoute>} />
        <Route path="/cart" element={<ProtectedRoute><Cart /></ProtectedRoute>} />
        <Route path="/orders" element={<ProtectedRoute><Orders /></ProtectedRoute>} />
        <Route path="/addaddress" element={<ProtectedRoute><AddAddress /></ProtectedRoute>} />
        <Route path="/updateaddress" element={<ProtectedRoute>< UpdateAddress /></ProtectedRoute>} />
        <Route path="/userprofile" element={<ProtectedRoute>< UserProfile /></ProtectedRoute>} />
        <Route path="/product" element={<ProtectedRoute>< Product /></ProtectedRoute>} />
        <Route path="/category" element={<ProtectedRoute><Category/></ProtectedRoute>} />
        <Route path="/productbycategory" element={<ProtectedRoute>< ProductByCategory /></ProtectedRoute>} />
        <Route path="/Orderhistory" element={<ProtectedRoute><OrderHistory /></ProtectedRoute>} />
        <Route path="/Orderconfirmation" element={<ProtectedRoute><OrderConfirmation /></ProtectedRoute>} />
        <Route path="/wishlist" element={<ProtectedRoute><Wishlist /></ProtectedRoute>} />
        <Route path="/verifyotp" element={<ProtectedRoute><VerifyOtp /></ProtectedRoute>} />
        {/* <Route path="/Voicebot" element={<ProtectedRoute><VoiceBot /></ProtectedRoute>} /> */}
        <Route path="/Payment" element={<ProtectedRoute><Elements stripe={stripePromise}><Payment /></Elements></ProtectedRoute>} />
      </Routes>
      <VoiceBot/>
    </Router>
    // <Router>
    //   <Routes>
    //     <Route path='/register' element={<Register />} />
    //     <Route path="/" element={<Login />} />
    //     <Route path="/homepage" element={<Homepage />} />
    //     <Route path="/address" element={<Address />} />
    //     <Route path="/cart" element={<Cart />} />
    //     <Route path="/orders" element={<Orders />} />
    //     <Route path="/addaddress" element={<AddAddress />} />
    //     <Route path="/updateaddress" element={< UpdateAddress />} />
    //     <Route path="/userprofile" element={< UserProfile />} />
    //     <Route path="/category" element={< Category />} />
    //     <Route path="/product" element={< Product />} />
    //     <Route path="/productbycategory" element={< ProductByCategory />} />
    //     <Route path="/Orderhistory" element={<OrderHistory />} />
    //   </Routes>
    // </Router>
  );
};

export default App;
