// import React from 'react';
// import { Page, Text, View, Document, StyleSheet, Image, pdf } from '@react-pdf/renderer';
// import main_logo from '../assets/images/main-logo.jpeg'


// // Styles for the PDF
// const styles = StyleSheet.create({
//     page: {
//         flexDirection: 'column',
//         justifyContent: 'center',
//         alignItems: 'center',
//         padding: 20,
//         border: '1px solid black',
//         position: 'relative',
//         width: '100%',
//         height: '100%'
//     },
//     header: {
//         position: 'absolute',
//         top: 20,
//         left: 20,
//         right: 20,
//         flexDirection: 'row',
//         justifyContent: 'space-between'
//     },
//     logo: {
//         width: 50,
//         height: 20
//     },
//     dateTime: {
//         textAlign: 'right'
//     },
//     title: {
//         fontSize: 16,
//         textAlign: 'center',
//         marginTop: 60,
//         marginBottom: 20,
//         fontWeight: 'bold'
//     },
//     content: {
//         fontSize: 12,
//         textAlign: 'left',
//         margin: 10
//     }
// });

// // PDF Document Component
// const MyPDFDocument = ({ orderdata }, amount, orderId) => (
//     <Document>
//         <Page size="A4" style={styles.page}>
//             {/* Header with Logo and Date/Time */}
//             <View style={styles.header}>
//                 <Image
//                     style={styles.logo}
//                     src={main_logo} // Path to your logo image
//                 />
//                 <View style={styles.dateTime}>
//                     <Text>Date: {new Date().toLocaleDateString()}</Text>
//                     <Text>Time: {new Date().toLocaleTimeString()}</Text>
//                 </View>
//             </View>

//             {/* Title */}
//             <Text style={styles.title}>Order Summary</Text>

//             {/* Order Details */}
//             {/* <View style={styles.content}>
//                 <Text>Item 1: $10</Text>
//                 <Text>Item 2: $20</Text>
//                 <Text>Item 3: $30</Text>
//                 <Text>----------------------</Text>
//                 <Text>Total: $60</Text>
//             </View> */}
//             <View style={styles.content}>
//                 {orderdata.map((item) => (
//                     <View key={item.cartId} style={styles.item}>
//                         <Text>Product: {item.productName}</Text>
//                         <Text>Quantity: {item.quantity}</Text>
//                         <Text>Price: ${item.price.toLocaleString()}</Text>
//                     </View>
//                 ))}
//             </View>
//             <Text style={styles.summary}>Total: ${amount}</Text>
//         </Page>
//     </Document>
// );

// export default MyPDFDocument;


// import React from 'react';
// import { Page, Text, View, Document, StyleSheet, Image } from '@react-pdf/renderer';
// import main_logo from '../assets/images/main-logo.jpeg'


// // Styles for the PDF
// const styles = StyleSheet.create({
//     page: {
//         flexDirection: 'column',
//         justifyContent: 'center',
//         alignItems: 'center',
//         padding: 20,
//         border: '1px solid black',
//         position: 'relative',
//         width: '100%',
//         height: '100%'
//     },
//     header: {
//         position: 'absolute',
//         top: 20,
//         left: 20,
//         right: 20,
//         flexDirection: 'row',
//         justifyContent: 'space-between'
//     },
//     logo: {
//         width: 50,
//         height: 20
//     },
//     dateTime: {
//         textAlign: 'right'
//     },
//     title: {
//         fontSize: 18,
//         textAlign: 'center',
//         marginTop: 80,
//         marginBottom: 20,
//         fontWeight: 'bold'
//     },
//     content: {
//         fontSize: 12,
//         textAlign: 'left',
//         margin: 10,
//         width: '100%',
//     },
//     item: {
//         marginBottom: 10,
//         borderBottom: '1px solid black',
//         paddingBottom: 5
//     },
//     summary: {
//         marginTop: 20,
//         fontWeight: 'bold',
//         textAlign: 'right'
//     },
//     orderId: {
//         marginTop: 10,
//         fontWeight: 'bold',
//         textAlign: 'right'
//     }
// });

// // PDF Document Component
// const OrderPDF = ({ orderdata, amount, orderId }) => {
//     return (
//         <Document>
//             <Page size="A4" style={styles.page}>
//                 {/* Header with Logo and Date/Time */}
//                 <View style={styles.header}>
//                     <Image
//                         style={styles.logo}
//                         src={main_logo} // Path to your logo image
//                     />
//                     <View style={styles.dateTime}>
//                         <Text>Date: {new Date().toLocaleDateString()}</Text>
//                         <Text>Time: {new Date().toLocaleTimeString()}</Text>
//                     </View>
//                 </View>

//                 {/* Title */}
//                 <Text style={styles.title}>Order Summary</Text>

//                 {/* Order ID */}
//                 <Text style={styles.orderId}>Order ID: {orderId}</Text>

//                 {/* Order Details */}
//                 <View style={styles.content}>
//                     {orderdata.map((item) => (
//                         <View key={item.cartId} style={styles.item}>
//                             <Text>Product: {item.productName}</Text>
//                             <Text>Quantity: {item.quantity}</Text>
//                             <Text>Price: ₹{item.price.toLocaleString()}</Text>
//                         </View>
//                     ))}
//                 </View>

//                 {/* Total Amount */}
//                 <Text style={styles.summary}>Total Amount: ${amount.toLocaleString()}</Text>
//             </Page>
//         </Document>
//     );
// };

// export default OrderPDF;


import React from 'react';
import { Page, Text, View, Document, StyleSheet, Image, Font } from '@react-pdf/renderer';
import main_logo from '../assets/images/main-logo.jpeg'

// Add a custom font if needed
// Font.register({
//   family: 'Helvetica',
//   src: 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/fonts/Helvetica.ttf'
// });

const styles = StyleSheet.create({
    page: {
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
        border: '1px solid black', // Page border
        position: 'relative',
        width: '100%',
        height: '100%'
    },
    header: {
        position: 'absolute',
        top: 20,
        left: 20,
        right: 20,
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    logo: {
        width: 50,
        height: 20
    },
    dateTime: {
        textAlign: 'right'
    },
    title: {
        fontSize: 18,
        textAlign: 'center',
        marginTop: 80,
        marginBottom: 20,
        fontWeight: 'bold'
    },
    content: {
        fontSize: 12,
        textAlign: 'left',
        margin: 10,
        width: '100%',
    },
    item: {
        marginBottom: 10,
        borderBottom: '1px solid black',
        paddingBottom: 5
    },
    summary: {
        marginTop: 20,
        fontWeight: 'bold',
        textAlign: 'right'
    },
    orderId: {
        marginTop: 10,
        fontWeight: 'bold',
        textAlign: 'right'
    }
});

// PDF Document Component
const OrderPDF = ({ orderdata, amount, orderId }) => {
    return (
        <Document>
            <Page size="A4" style={styles.page}>
                {/* Header with Logo and Date/Time */}
                <View style={styles.header}>
                    <Image
                        style={styles.logo}
                        src={main_logo} // Path to your logo image
                    />
                    <View style={styles.dateTime}>
                        <Text>Date: {new Date().toLocaleDateString()}</Text>
                        <Text>Time: {new Date().toLocaleTimeString()}</Text>
                    </View>
                </View>

                {/* Title */}
                <Text style={styles.title}>Order Summary</Text>

                {/* Order ID */}
                <Text style={styles.orderId}>Order ID: {orderId}</Text>

                {/* Order Details */}
                <View style={styles.content}>
                    {orderdata.map((item) => (
                        <View key={item.cartId} style={styles.item}>
                            <Text>Product: {item.productName}</Text>
                            <Text>Quantity: {item.quantity}</Text>
                            <Text>Price: ₹{item.price.toLocaleString()}</Text>
                        </View>
                    ))}
                </View>

                {/* Total Amount */}
                <Text style={styles.summary}>Total Amount: ₹{amount.toLocaleString()}</Text>
            </Page>
        </Document>
    );
};

export default OrderPDF;
