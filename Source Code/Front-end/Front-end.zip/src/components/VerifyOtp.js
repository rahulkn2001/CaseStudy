import React, { useReducer, useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
// Initial state and reducer function for user ID
const initialState = {
  userId: null,
};
const userReducer = (state, action) => {
  switch (action.type) {
    case 'SET_USER_ID':
      return { ...state, userId: action.payload };
    default:
      return state;
  }
};
const VerifyOtp = () => {
  // State hooks for OTP and messages
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  // useReducer for managing userId
  const [state, dispatch] = useReducer(userReducer, initialState);
  const { userId } = state;
  const navigate = useNavigate();
  const location = useLocation();
  // Initialize userId from location state or fallback to initialState
  useEffect(() => {
    if (location.state && location.state.userId) {
      dispatch({ type: 'SET_USER_ID', payload: location.state.userId });
    }
  }, [location.state]);
  const handleOtpChange = (e) => setOtp(e.target.value);
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('https://localhost:7137/api/Register/verifyemail', {
        token: otp,
        userId: userId
      }, {
        headers: { 'Content-Type': 'application/json' }
      });
      if (response.data === 'successfully verified') {
        setSuccessMessage('OTP verified successfully!');
        navigate('/'); // Redirect to the home page or login page
      } else {
        setError('Invalid OTP.');
      }
    } catch (error) {
      setError('OTP verification failed: ' + (error.response?.data || error.message));
    }
  };
  return (
    <div>
      <h2>Verify OTP</h2>
      <form onSubmit={handleSubmit}>
        <label>
          OTP
          <input type="text" value={otp} onChange={handleOtpChange} />
        </label>
        <br />
        <button type="submit">Verify OTP</button>
      </form>
      {error && <div className="error">{error}</div>}
      {successMessage && <div className="success">{successMessage}</div>}
    </div>
  );
};

export default VerifyOtp;