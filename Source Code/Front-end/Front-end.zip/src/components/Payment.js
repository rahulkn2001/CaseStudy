import React, { useState } from 'react';
import { useStripe, useElements, CardElement } from '@stripe/react-stripe-js';
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import './Payment.css'; // Import the CSS file
const Payment = () => {
  const stripe = useStripe();
  const elements = useElements();
  const location = useLocation();
  const [loading, setLoading] = useState(false);
  const [succs,setSuccs] = useState(null);
  const [error, setError] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState('card'); // Default payment method
  // Retrieve total amount and order ID from the location state
  const { orderId, totalAmount, cartProducts } = location.state || {};
  const navigate = useNavigate();


  console.log(orderId, totalAmount);
  const handlePaymentMethodChange = (method) => {
    setPaymentMethod(method);
  };
  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!stripe || !elements) {
      return;
    }
    setLoading(true);
    setError(null);
    try {
      console.log({
        amount: Math.round(totalAmount * 100), // Convert amount to smallest currency unit
        paymentMethodType: paymentMethod,
        orderId: orderId,
      })
      // Make sure to include all required fields in the request
      const { data: { clientSecret } } = await axios.post('https://localhost:7255/api/Payment/create-payment-intent', {
        amount: Math.round(totalAmount), // Convert amount to smallest currency unit
        paymentMethodType: paymentMethod,
        orderId: orderId,
      });
      if (paymentMethod === 'card') {
        // Handle card payments
        const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
          payment_method: {
            card: elements.getElement(CardElement),
          },
        });
        if (error) {
          setError(error.message);
        } else if (paymentIntent.status === 'succeeded') {
          console.log('Payment succeeded:', paymentIntent);
          navigate('/orderconfirmation', {
            state: { orderId, totalAmount, cartProducts }
          })
          // setSuccs(paymentIntent)
          // Handle successful payment here
        }
      } else if (paymentMethod === 'cashOnDelivery') {
        // Handle Cash on Delivery
        console.log('Order placed with Cash on Delivery.');
        navigate('/orderconfirmation', {
          state: { orderId, totalAmount, cartProducts }
        })
        // setSuccs("Order placed with Cash on Delivery")
        // Handle post-payment actions here
      } else {
        setError('Unsupported payment method');
      }
    } catch (error) {
      setError(error.message);
    }
    setLoading(false);
  };
  // Custom styling for CardElement
  const cardElementOptions = {
    style: {
      base: {
        fontSize: '16px',
        color: '#424770',
        '::placeholder': {
          color: '#AAB7C4',
        },
        border: '1px solid #007BFF', // Border for card fields
        padding: '12px', // Padding around the card element
      },
      invalid: {
        color: '#9E2146',
      },
    },
  };
  return (
    <div className="payment-container">
      <h2>Payment</h2>
      <div className="payment-content">
        <div className="payment-methods">
          <div
            className={`payment-method-card ${paymentMethod === 'card' ? 'selected' : ''}`}
            onClick={() => handlePaymentMethodChange('card')}
          >
            <h3>Credit/Debit Card</h3>
          </div>
          <div
            className={`payment-method-card ${paymentMethod === 'phonepe' ? 'selected' : ''}`}
            onClick={() => handlePaymentMethodChange('phonepe')}
          >
            <h3>UPI</h3>
          </div>
          <div
            className={`payment-method-card ${paymentMethod === 'cashOnDelivery' ? 'selected' : ''}`}
            onClick={() => handlePaymentMethodChange('cashOnDelivery')}
          >
            <h3>Cash on Delivery</h3>
          </div>
        </div>
        <div className="payment-details">
          {paymentMethod === 'card' && (
            <div className="card-element-container">
              <CardElement options={cardElementOptions} />
            </div>
          )}
          {paymentMethod === 'phonepe' && (
            <div className="phonepe-info">
              <p>PhonePe payment method integration might require custom handling, typically through a UPI ID or PhonePe interface.</p>
              <label>
                UPI ID:
                <input type="text" className="input-field" placeholder="example@upi" />
              </label>
            </div>
          )}
          {paymentMethod === 'cashOnDelivery' && (
            <div className="cod-info">
              <p>Cash on Delivery will be collected when the product is delivered.</p>
            </div>
          )}
          <button
            type="submit"
            className="submit-button"
            onClick={handleSubmit}
            disabled={loading}
          >
            {loading ? 'Processing...' : (paymentMethod === 'cashOnDelivery' ? 'Place Order' : 'Pay')}
          </button>
        </div>
      </div>
      {error && <p className="error-message">{error}</p>}
      {/* {succs && <p className="succs-message">{succs}</p>} */}

    </div>
  );
};
export default Payment;