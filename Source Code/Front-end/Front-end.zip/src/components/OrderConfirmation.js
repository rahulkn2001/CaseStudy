import React from 'react'
import Confirmed from '../assets/Confirmed.mp4'
import './Orderhisroy.css'
import jsPDF from 'jspdf';
import main_logo from '../assets/images/main-logo.jpeg'
import Orderpdf from './OrderPDF'
import { pdf } from '@react-pdf/renderer';
import { useLocation } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';





function OrderConfirmation() {


    const location = useLocation();
    const navigate = useNavigate();

    const { orderId, totalAmount, cartProducts } = location.state || {};
    console.log(orderId, totalAmount, cartProducts)

    const createPDF1 = () => {
        // const doc = new jsPDF();
        // doc.text('Hello world!', 10, 10);
        // doc.text('This is a PDF document generated with jsPDF.', 10, 20);
        // doc.save('generated.pdf');

        const doc = new jsPDF();
        const logoImg = new Image();
        logoImg.src = main_logo; // Path to your logo image

        const margin = 15;
        const pageWidth = doc.internal.pageSize.width;
        const pageHeight = doc.internal.pageSize.height;

        // Add company logo
        doc.addImage(logoImg, 'PNG', margin, margin, 50, 20);

        // Add border
        doc.rect(margin, margin, pageWidth - 2 * margin, pageHeight - 2 * margin);

        // Add date and time
        const now = new Date();
        const dateString = now.toLocaleDateString();
        const timeString = now.toLocaleTimeString();
        doc.setFontSize(12);
        doc.text(`Date: ${dateString}`, pageWidth - margin - 40, margin + 10);
        doc.text(`Time: ${timeString}`, pageWidth - margin - 40, margin + 20);

        // Add heading
        doc.setFontSize(16);
        doc.setFont('Helvetica', 'bold');
        doc.text('Order Summary', margin, margin + 40);

        // Add order details and summary
        doc.setFontSize(12);
        doc.setFont('Helvetica', 'normal');
        const details = [
            'Item 1: $10',
            'Item 2: $20',
            'Item 3: $30',
            '----------------------',
            'Total: $60'
        ];

        details.forEach((line, index) => {
            doc.text(line, margin, margin + 50 + (10 * index));
        });

        // Save the PDF
        doc.save('order-summary.pdf');
    };


    const createPDF = async () => {
        const blob = await pdf(<Orderpdf orderdata={cartProducts} amount={totalAmount} orderId={orderId} />).toBlob();
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'order-summary.pdf';
        link.click();
    };


    return (
        <div className='confirmation-container'>
            <video className='confirmation-video' width="600" autoPlay muted>
                <source src={Confirmed} type="video/mp4" />
                Your browser does not support the video tag.
            </video>
            <div className='confirmation-buttons-container'>
                <div className='confirmation-text'>Your Order is confirmed!<br></br>Thank you for shopping with us</div>
                <div className='confirmation-buttons-subcontainer'>
                    <button className='confirmation-buttons confirmation-button-left' onClick={()=>{navigate('/homepage')}}>Back to Home</button>
                    <button className='confirmation-buttons confirmation-button-right' onClick={createPDF} >Download Receipt</button>
                </div>
            </div>
        </div>
    )
}

export default OrderConfirmation
