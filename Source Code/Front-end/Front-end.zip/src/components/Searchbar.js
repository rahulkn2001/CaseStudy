import React, { useState, useRef, useEffect } from 'react';
import "./Homepage.css";
import { useNavigate } from 'react-router';
import axios from 'axios';
import "./Searchbar.css"
import { FaBell } from 'react-icons/fa';
function Searchbar() {


    // const products = [
    //     { "productId": 0, "productName": "Fridge", "price": 49999, "categoryName": null, "specification": null, "images": null },
    //     { "productId": 1, "productName": "Smartphone", "price": 699.99, "categoryName": null, "specification": null, "images": null },
    //     { "productId": 2, "productName": "Laptop", "price": 999.99, "categoryName": null, "specification": null, "images": null },
    //     { "productId": 3, "productName": "Novel", "price": 19.99, "categoryName": null, "specification": null, "images": null },
    //     { "productId": 4, "productName": "Microwave", "price": 89.99, "categoryName": null, "specification": null, "images": null }
    // ];

    const products = [
        {
            ProductId: 5,
            productName: 'Iphone 10',
            Price: 40000.00,
            CategoryID: 5,
            Specification: '64GB, 4GB RAM, 4000mAh Battery',
            InventoryId: 5
        },
        {
            ProductId: 6,
            productName: 'Iphone 13',
            Price: 40000.00,
            CategoryID: 5,
            Specification: '32GB, 8GB RAM, 4000mAh Battery',
            InventoryId: 6
        },
        {
            ProductId: 7,
            productName: 'Iphone 14',
            Price: 40000.00,
            CategoryID: 5,
            Specification: '32GB, 8GB RAM, 4000mAh Battery',
            InventoryId: 7
        },
        {
            ProductId: 8,
            productName: 'Iphone 15',
            Price: 40000.00,
            CategoryID: 5,
            Specification: '32GB, 8GB RAM, 4000mAh Battery',
            InventoryId: 8
        },
        {
            ProductId: 9,
            productName: 'Iphone 11',
            Price: 40000.00,
            CategoryID: 5,
            Specification: '32GB, 8GB RAM, 4000mAh Battery',
            InventoryId: 9
        },
        {
            ProductId: 10,
            productName: 'Audi',
            Price: 1400000.00,
            CategoryID: 8,
            Specification: '2.2L diesel engine, 6-speed manual, 4x4 driv',
            InventoryId: 30
        },
        {
            ProductId: 11,
            productName: 'BMW',
            Price: 4000000.00,
            CategoryID: 8,
            Specification: '3.0L inline-6, 8-speed automatic, rear-wheel drive',
            InventoryId: 10
        },
        {
            ProductId: 12,
            productName: 'Mercedes Benz',
            Price: 4000000.00,
            CategoryID: 8,
            Specification: '2.0L turbo, 9-speed automatic, MBUX infotainment',
            InventoryId: 11
        },
        {
            ProductId: 13,
            productName: 'Porche',
            Price: 5000000.00,
            CategoryID: 8,
            Specification: '3.0L V6 twin-turbo, 8-speed PDK, sport mode',
            InventoryId: 12
        },
        {
            ProductId: 14,
            productName: 'Thar',
            Price: 1500000.00,
            CategoryID: 8,
            Specification: '2.2L diesel engine, 6-speed manual, 4x4 drive',
            InventoryId: 13
        },
        {
            ProductId: 15,
            productName: 'Activa',
            Price: 150000.00,
            CategoryID: 7,
            Specification: '110cc engine, CVT transmission, 5.3L fuel tank',
            InventoryId: 14
        },
        {
            ProductId: 16,
            productName: 'Bajaj',
            Price: 120000.00,
            CategoryID: 7,
            Specification: '150cc DTS-i engine, 5-speed gearbox, alloy wheels',
            InventoryId: 15
        },
        {
            ProductId: 17,
            productName: 'Royal Enfield',
            Price: 180000.00,
            CategoryID: 7,
            Specification: '350cc single-cylinder, 5-speed, classic design',
            InventoryId: 16
        },
        {
            ProductId: 18,
            productName: 'Duke',
            Price: 200000.00,
            CategoryID: 7,
            Specification: '200cc liquid-cooled engine, 6-speed, aggressive styling',
            InventoryId: 17
        },
        {
            ProductId: 19,
            productName: 'Himalayan',
            Price: 250000.00,
            CategoryID: 7,
            Specification: '411cc, long-travel suspension, adventure-ready',
            InventoryId: 18
        },
        {
            ProductId: 20,
            productName: 'RX100',
            Price: 100000.00,
            CategoryID: 6,
            Specification: '98cc 2-stroke engine, 4-speed, retro design',
            InventoryId: 23
        },
        {
            ProductId: 21,
            productName: 'Buddha Show Piece',
            Price: 80000.00,
            CategoryID: 6,
            Specification: 'Buddha Idols for Home Decor, Handcrafted Buddha Sculpture, Spiritual Gift Item',
            InventoryId: 24
        },
        {
            ProductId: 22,
            productName: 'Mask Show Piece',
            Price: 60000.00,
            CategoryID: 6,
            Specification: 'Decorative Mask for Wall, Handcrafted Mask Sculpture, Art Decor Piece',
            InventoryId: 25
        },
        {
            ProductId: 23,
            productName: 'Rabbit Show Piece',
            Price: 50000.00,
            CategoryID: 6,
            Specification: 'Handcrafted Rabbit Figurine, Showpiece for Living Room, Home Decor',
            InventoryId: 26
        },
        {
            ProductId: 24,
            productName: 'Shiva Show Piece',
            Price: 120000.00,
            CategoryID: 6,
            Specification: 'Shiva Idols for Showpiece, Handcrafted Lord Shiva Sculpture, Religious Gift Item',
            InventoryId: 21
        },
        {
            ProductId: 25,
            productName: 'Tree Show Piece',
            Price: 70000.00,
            CategoryID: 6,
            Specification: 'Decorative Tree Sculpture, Metal Tree Showpiece for Home Decor, Gift Item',
            InventoryId: 29
        },
        {
            ProductId: 26,
            productName: 'Gym Gloves',
            Price: 5000.00,
            CategoryID: 9,
            Specification: 'High-quality gym gloves, Adjustable straps, Provides better grip and protection',
            InventoryId: 28
        },
        {
            ProductId: 29,
            productName: 'Gym Bag',
            Price: 120000.00,
            CategoryID: 9,
            Specification: 'Spacious main compartment, Multiple zippered pockets for organization, Durable, water-resistant fabric',
            InventoryId: 33
        },
        {
            ProductId: 31,
            productName: 'Gym Bottle',
            Price: 1500.00,
            CategoryID: 9,
            Specification: 'Durable plastic gym bottle, 1-liter capacity, Leak-proof design',
            InventoryId: 31
        },
        {
            ProductId: 32,
            productName: 'Gym Shoes',
            Price: 8000.00,
            CategoryID: 9,
            Specification: 'Comfortable gym shoes, Breathable mesh upper, Cushioned sole for shock absorption',
            InventoryId: 32
        },
        {
            ProductId: 33,
            productName: 'Gym Bag',
            Price: 120000.00,
            CategoryID: 9,
            Specification: 'Spacious main compartment, Multiple zippered pockets for organization, Durable, water-resistant fabric',
            InventoryId: 30
        }
    ];



    const [isDropdownVisible, setIsDropdownVisible] = useState(false);
    const [notifications, setNotifications] = useState([]);
    const [notificationsVisible, setNotificationsVisible] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const dropdownRef = useRef(null);
    const inputRef = useRef(null);



    const handleNotificationClick = () => {
        setNotificationsVisible(!notificationsVisible);
    };
    const handleOptionClick = (option) => {
        setSearchTerm(option);
        setIsDropdownVisible(false);
    };

    useEffect(() => {
        const userId = localStorage.getItem('userid');
        const token = localStorage.getItem('token');
        const fetchNotifications = async () => {
            try {
                const res = await axios.get(`https://localhost:7041/api/Notification/${userId}`, {
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${token}`
                    }
                });
                setNotifications(res.data);
            } catch (error) {
                console.error('Error fetching notifications:', error);
            }
        };
        fetchNotifications();
    }, [])


    useEffect(() => {
        // Hide dropdown if clicking outside of the component
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target) && !inputRef.current.contains(event.target)) {
                setIsDropdownVisible(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleInputFocus = () => {
        setIsDropdownVisible(true);
    };

    // const handleInputChange = (e) => {
    //     setSearchTerm(e.target.value);
    // };






    const [query, setQuery] = useState('');
    const [filteredProducts, setFilteredProducts] = useState([]);

    // Handle input change
    const handleInputChange = (event) => {
        const { value } = event.target;
        setSearchTerm(value);

        // Filter products based on the query
        if (value) {
            const filtered = products.filter(product =>
                product.productName.toLowerCase().includes(value.toLowerCase())
            );
            setFilteredProducts(filtered);
        } else {
            setFilteredProducts([]);
        }
    };

    const handleRedirect = (prop) => {
        console.log(prop)
        const selectedId = prop;
        navigate('/product', { state: selectedId });
    }
    const navigate = useNavigate();
    const unreadCount = notifications.filter((notif) => !notif.read).length;
    return (
        <div class="home-top-bar">
            <span></span>
            <div className="home-search-container" style={{ width: '90%' }}>
                {/* <input className="home-search-bar" type='text' placeholder='Search for your products' value={query}
                    onChange={handleInputChange}
                />
                <div size="5" style={{ width: '100%' }} className='home-search-items'>
                    {filteredProducts.length > 0 ? (
                        filteredProducts.map(product => (
                            <div key={product.productId} value={product.productId} onClick={()=>{handleRedirect(product.productId)}}>
                                {product.productName}
                            </div>
                        ))
                    ) : (
                        <></>
                    )}
                </div> */}

                <input
                    type="text"
                    value={searchTerm}
                    onChange={handleInputChange}
                    onFocus={handleInputFocus}
                    ref={inputRef}
                    placeholder="Search..."
                    autoComplete="off"
                    className='search-bar-input'
                />
                {/* <button>Search</button> */}
                {isDropdownVisible && (
                    <div className="dropdown" ref={dropdownRef}>
                        {/* <ul>
                            <li onClick={() => handleOptionClick('Option 1')}>Option 1</li>
                            <li onClick={() => handleOptionClick('Option 2')}>Option 2</li>
                            <li onClick={() => handleOptionClick('Option 3')}>Option 3</li>
                        </ul> */}
                        {filteredProducts.length > 0 ? (
                            filteredProducts.map(product => (
                                <div key={product.productId} className='search-options' value={product.productId} onClick={() => { handleRedirect(product.ProductId) }} style={{ cursor: "pointer" }}>
                                    {product.productName}
                                </div>
                            ))
                        ) : (
                            <></>
                        )}
                    </div>
                )}
            </div>
            <div className='top-bar-icons'>
                <div className="position-relative notification-container notifications-icon">
                    <FaBell className='notification-bell-icon' size={30} onClick={handleNotificationClick} style={{ cursor: 'pointer' }} />
                    {/* {unreadCount > 0 && (
                        <span
                            style={{
                                position: 'absolute',
                                top: '-4px',
                                right: '1px',
                                backgroundColor: 'red',
                                color: 'white',
                                borderRadius: '50%',
                                width: '20px',
                                height: '20px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontSize: '12px',
                            }}
                        >
                            {unreadCount}
                        </span>
                    )} */}
                    {notificationsVisible && (
                        // <div className="position-absolute w-100 mt-1 bg-white border rounded shadow">
                        <div className='dropdown-notifications'>
                            {notifications.length === 0 ? (
                                <div className="p-2 text-muted">No notifications</div>
                            ) : (
                                notifications.map((notif) => (
                                    <div key={notif.id} className="p-2 notification-options">
                                        {notif.message}
                                    </div>
                                ))
                            )}
                        </div>
                    )}
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16" onClick={() => { navigate('/userprofile') }}>
                    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0" />
                    <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1" />
                </svg>
            </div>
        </div>
    )
}

export default Searchbar
