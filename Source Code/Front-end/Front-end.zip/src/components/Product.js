import React, { useEffect, useState } from 'react'
import axios from 'axios';
import Navbar from './Navbar';
import Searchbar from './Searchbar';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
// import sample from '../assets/images/unsplash-free-stock-photo.png'
// import img1 from "../assets/Categories/1.png"
import "./Product.css"
import "./Wishlist.css"

function Product() {
    const [product, setProduct] = useState(null)
    const [relatedProducts, setRelatedProducts] = useState(null);
    const [productRating, setProductRating] = useState(null);
    const [productStock, setProductStock] = useState();
    const [quantity, setQuantity] = useState(1);
    const [productReviews, setProductReviews] = useState();
    const [wishlist, setWishlist] = useState([]);
    const [isWishlist, setIsWishlist] = useState(false);
    const [iconClicked, setIconClicked] = useState(false);
    const [newReview, setNewReview] = useState({
        userId: '',
        rating: 1, // Default rating
        comments: ''
    })


    const location = useLocation();
    const data = location.state || { data: { message: 'No data passed' } };

    const handleIncrement = () => {
        setQuantity(prevQuantity => prevQuantity + 1);
    };

    const handleDecrement = () => {
        setQuantity(prevQuantity => (prevQuantity > 0 ? prevQuantity - 1 : 0));
    };

    const handleRedirect = (prop) => {
        console.log(prop)
        const selectedId = prop;
        navigate('/product', { state: selectedId });
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        setNewReview({
            ...newReview,
            [name]: value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        setNewReview({
            userId: '',
            rating: 1,
            comments: ''
        });
    };



    const navigate = useNavigate();

    const addToCart = async () => {
        // alert(`Submitted quantity: ${quantity}`);
        toast.success(`Submitted quantity: ${quantity} added to cart!`);
        const userId = localStorage.getItem('userid')
        try {
            const response = await axios.post('https://localhost:7185/api/Cart/add', {
                userId: userId,
                productId: data,
                quantity: quantity
            }, {
                headers: {
                    'Accept': '*/*',
                    'Content-Type': 'application/json'
                },
                // If you are using HTTPS locally with self-signed certificates,
                // you may need to handle SSL verification or use a trusted certificate.
            });

            console.log('Response:', response.data);
        } catch (error) {
            console.error('Error adding to cart:', error);
        }
        setQuantity(1);
    };

    const handleWishlist = async () => {
        const userId = localStorage.getItem('userid');
        try {
            console.log(product);
            if (isWishlist) {
                await axios.delete(`https://localhost:7174/api/WishlistItems/${userId}/${product.productId}`);
                setIsWishlist(false);
                setIconClicked(false); // Update icon clicked state
            } else {
                await axios.post(`https://localhost:7174/api/WishlistItems/${userId}/${product.productId}`);
                setIsWishlist(true);
                setIconClicked(true); // Update icon clicked state
            }
        } catch (error) {
            console.error('Error handling wishlist:', error);
        }
    };


    // useEffect(() => {
    //     if (!relatedProducts) {
    //         const displayedProducts = relatedProducts
    //             .filter(item => item.productId !== product.productId)
    //             .slice(0, 3);
    //         setRelatedProducts(displayedProducts)
    //     }
    // }, [relatedProducts])

    // useEffect(() => {
    //     const fetchReviews = async () => {
    //         try {
    //             const response = await axios.get(`https://localhost:7185/${product.productId}`)
    //             setProductReviews(response.data)
    //         }
    //         catch (e) {
    //             console.log(e)
    //         }
    //     }
    //     fetchReviews();
    // }, [product])

    useEffect(() => {
        const fetchRelatedProducts = async () => {
            try {
                const response = await axios.get(`https://localhost:7185/api/Product/bycategory/${product.categoryName}`)
                setRelatedProducts(response.data)
                const response2 = await axios.get(`https://localhost:7185/api/Inventory/${product.productId}`)
                setProductStock(response2.data.stockQuantity)
                const response3 = await axios.get(`https://localhost:7185/${product.productId}`)
                setProductReviews(response3.data)
            }
            catch (e) {
                console.log(e)
            }
        }
        fetchRelatedProducts()
    }, [product])

    useEffect(() => {
        const fetchProductDetails = async () => {
            try {
                const response = await axios.get(`https://localhost:7185/api/Product/products/${data}`)
                setProduct(response.data)
                const response2 = await axios.get(`https://localhost:7185/api/Product/averageratings/${data}`)
                setProductRating(response2.data.avgRating)

            }
            catch (e) {
                console.log(e)
            }
        }
        fetchProductDetails();
    }, [data])


    // useEffect(() => {
    //     const fetchProducts = async () => {
    //         console.log(data)
    //         try {
    //             const response = await axios.get(`https://localhost:7185/api/Product/bycategory/${product.categoryName}`)
    //             setRelatedProducts(response.data)
    //             console.log(response.data)
    //         }
    //         catch (e) {
    //             console.log(e)
    //         }

    //     }
    //     fetchProducts()
    // }, [])
    const clampedRating = Math.max(0, Math.min(productRating ?? 0, 5));
    // const clampedRating = 4;
    console.log(productReviews)
    // if (isLoading) {
    //     return <div>Loading...</div>; // Show loading state
    //   }
    return (
        <div class="home-main-container">
            <Navbar />
            <div className='home-sub-container'>
                <Searchbar />
                {/* <div>{product?.productId}</div> */}
                <div className='product-main-container'>
                    <div className='product-details-container'>
                        <img className='product-image' src={`data:image/jpeg;base64,${product?.images}`} />
                        <div className='product-information'>
                            <div className='product-information-title'>{product?.productName}</div>
                            <div className='product-information-subtext'>₹{product?.price}</div>
                            <div className='product-rating'>
                                {[1, 2, 3, 4, 5].map((star) => (
                                    <span
                                        key={star}
                                        className={`star ${star <= clampedRating ? 'filled' : ''}`}
                                    >
                                        ★
                                    </span>
                                ))}
                            </div>
                            {
                                productStock < 85 ? (<div style={{ color: "red", padding: "5px" }}> HURRY! only {productStock} remaining </div>) : (<></>)
                            }
                            <div className="product-quantity-controls">
                                <button className="product-quantity-btn" onClick={handleDecrement}>-</button>
                                <input type="text" value={quantity} readOnly className="product-quantity-input" />
                                <button className="product-quantity-btn" onClick={handleIncrement}>+</button>
                                <span
                                    className={`wishlist-icon ${isWishlist ? 'filled' : ''} ${iconClicked ? 'clicked' : ''}`}
                                    onClick={handleWishlist}
                                >
                                    ♥
                                </span>
                            </div>
                            <button className="product-submit-btn" onClick={addToCart}>Add to Cart</button>
                            <div className='product-information-description'>{product?.specification}Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</div>


                            <div className='product-reviews'>
                                <h2>View Product Reviews: {productReviews ? productReviews.length : 0}</h2>
                                <div className="add-review">
                                    <h3>Add a New Review</h3>
                                    <form onSubmit={handleSubmit}>
                                        <label>
                                            Rating:
                                            <select
                                                name="rating"
                                                value={newReview.rating}
                                                onChange={handleChange}
                                            >
                                                {[1, 2, 3, 4, 5].map((star) => (
                                                    <option key={star} value={star}>
                                                        {star}
                                                    </option>
                                                ))}
                                            </select>
                                        </label>
                                        <label>
                                            Comment:
                                            <textarea
                                                name="comments"
                                                value={newReview.comments}
                                                onChange={handleChange}
                                                required
                                            />
                                        </label>
                                        <button type="submit">Submit Review</button>
                                    </form>
                                </div>

                                {productReviews?.map((item) => (
                                    <div class="review-card">
                                        <div class="review-header">
                                            <div class="reviewer-name">{item.userId}</div>
                                        </div>
                                        {[1, 2, 3, 4, 5].map((star) => (
                                            <span
                                                key={star}
                                                className={`star ${star <= item.rating ? 'filled' : ''}`}
                                            >
                                                ★
                                            </span>
                                        ))}
                                        <div class="review-comment">
                                            <p>{item.comments}</p>
                                        </div>
                                    </div>
                                    // <span>{item.comments}</span>
                                ))}
                            </div>
                        </div>
                    </div>
                    <div className='product-related'>
                        <h1 style={{ color: "gray" }}>
                            You may also like
                        </h1>
                        {
                            relatedProducts?.map((item) => (
                                <div
                                    key={item.productId}
                                    className='product-related-cards'
                                    onClick={() => { handleRedirect(item.productId) }}
                                >
                                    <img src={`data:image/jpeg;base64,${item.images}`} className="product-related-card-image" />
                                    <div className="product-card-body">
                                        <h2 className="product-card-title" >{item.productName}</h2>
                                        <p className="product-card-price">₹{item.price}</p>
                                    </div>
                                </div>
                            ))
                        }
                    </div>
                    {/* <div className='product-reviews'>

                        {productReviews?.map((item) => (
                            <div class="review-card">
                                <div class="review-header">
                                    <span class="reviewer-name">{item.userId}</span>
                                    {[1, 2, 3, 4, 5].map((star) => (
                                        <span
                                            key={star}
                                            className={`star ${star <= item.rating ? 'filled' : ''} review-rating`}
                                        >
                                            ★
                                        </span>
                                    ))}
                                </div>
                                <div class="review-comment">
                                    <p>{item.comments}</p>
                                </div>
                            </div>
                            <span>{item.comments}</span>
                        ))}
                    </div> */}
                </div>
            </div>
        </div>
    )
}

export default Product
