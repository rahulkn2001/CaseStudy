// Homepage.jsx
import React, { useState, Suspense } from 'react';
import Navbar from './Navbar';
import "./Homepage.css"
import { useNavigate } from 'react-router';
import img1 from '../assets/images/main-logo.jpeg'
import img2 from '../assets/images/banner.svg'
import Searchbar from './Searchbar';
import axios from 'axios';


// import Carousel from 'react-bootstrap/Carousel';
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import { useEffect } from 'react';
import { Link } from 'react-router-dom';


const Homepage = () => {

  // const getRandomNumber = (min, max) => {
  //   return Math.floor(Math.random() * (max - min + 1)) + min;
  // };
  const [product1, setProduct1] = useState();
  const [product2, setProduct2] = useState();
  const [product3, setProduct3] = useState();
  const [product, setProduct] = useState();
  const [randomItems, setRandomItems] = useState([]);


  const [featuredProducts, setFeaturedProducts] = useState();

  // function generateRandomNumber() {
  //   // You can define the range of random numbers here. For example, 0 to 100
  //   const number = Math.floor(Math.random() * 4);
  //   // setRandomNumber(number);
  //   return number;
  // };


  const handleRedirect = (prop) => {
    console.log(prop)
    const selectedId = prop;
    navigate('/product', { state: selectedId });
  }


  useEffect(() => {
    const fetchFeatured = async () => {
      // const randomNumber = generateRandomNumber();
      try {
        const response = await axios.get(`https://localhost:7185/api/Product/productsAll`)
        console.log(response)
        setProduct(response.data)
        // console.log(product[0].productName)
      }
      catch (e) {
        console.log(e)
      }
    }
    fetchFeatured()
    // setFeaturedProducts(...featuredProducts, product)
    // fetchFeatured()
    // setFeaturedProducts(...featuredProducts, product)

  }, [])

  // useEffect(() => {
  //   // Function to get random items
  //   const getRandomItems = (arr, num) => {
  //     const shuffled = arr.sort(() => 0.5 - Math.random());
  //     return shuffled.slice(0, num);
  //   };

  //   // Update randomItems state with 3 random items from sourceArray
  //   setRandomItems(getRandomItems(product, 3));
  // }, [product]); 
  useEffect(() => {
    const getRandomItems = (arr, num) => {
      if (!arr || !Array.isArray(arr) || arr.length === 0) {
        return []; // Return an empty array if arr is not valid
      }

      // Ensure num is not greater than the length of the array
      const count = Math.min(num, arr.length);

      const shuffled = arr.slice().sort(() => 0.5 - Math.random());
      return shuffled.slice(0, count);
    };

    // Update randomItems state with 3 random items from sourceArray
    setRandomItems(getRandomItems(product, 3));
  }, [product]);


  const navigate = useNavigate();
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <div class="home-main-container">
        <Navbar />
        <div className='home-sub-container'>
          <Searchbar />
          <div class="home-featured-containers">
            <div class="home-sub-1">
              <h1 class="home-featured-titles">
                Featured Products
              </h1>
              {/* <div className='sub-1-cards'> */}
              {/* <div className='sub-1-card'>

              </div> */}
              <div className='carousel-container'>
                <Carousel
                  className='carousel-wrapper'
                  infiniteLoop={true}
                  autoPlay={true}
                  interval={3000}
                  showArrows={false}
                >
                  {
                    randomItems?.map((item) => (
                      <div className='carousel-slide' onClick={() => { handleRedirect(item.productId) }}>
                        <img className='carousel-slide-img' src={`data:image/jpeg;base64,${item.images}`}/>
                        <div className='legend'>
                          <span className='legend-span'>{item.productName}</span>
                        </div>
                      </div>
                    ))
                  }

                </Carousel>
              </div>
              {/* <div className='sub-1-card'>

              </div>
            </div> */}
            



            </div>
          </div>
        </div>

      </div>
    </Suspense>
  );
};

export default Homepage;
