// AddressEditModal.js
import React, { useState } from 'react';
import './AddressEditModal.css'; // Import the CSS file for styling

const AddressEditModal = ({ isOpen, onRequestClose, address, onSave }) => {
  const [editedAddress, setEditedAddress] = useState(address);

  const handleChange = (e) => {
    setEditedAddress({
      ...editedAddress,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = () => {
    onSave(editedAddress);
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onRequestClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <h2>Edit Address</h2>
        <label>House Number:</label>
        <input
          type="text"
          name="houseNumber"
          value={editedAddress.houseNumber}
          onChange={handleChange}
        />
        <label>Address Line 1:</label>
        <input
          type="text"
          name="addressline1"
          value={editedAddress.addressline1}
          onChange={handleChange}
        />
        <label>Address Line 2:</label>
        <input
          type="text"
          name="addressline2"
          value={editedAddress.addressline2}
          onChange={handleChange}
        />
        <label>City:</label>
        <input
          type="text"
          name="city"
          value={editedAddress.city}
          onChange={handleChange}
        />
        <label>State:</label>
        <input
          type="text"
          name="state"
          value={editedAddress.state}
          onChange={handleChange}
        />
        <label>Zipcode:</label>
        <input
          type="text"
          name="zipcode"
          value={editedAddress.zipcode}
          onChange={handleChange}
        />
        <div className="modal-actions">
          <button onClick={handleSubmit}>Save</button>
          <button onClick={onRequestClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
};

export default AddressEditModal;