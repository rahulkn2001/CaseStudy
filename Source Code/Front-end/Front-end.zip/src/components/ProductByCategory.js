import React, { useState, useEffect } from 'react'
import axios from 'axios';
// import img1 from "../assets/Categories/1.png"
import Navbar from './Navbar';
import Searchbar from './Searchbar';
import { useLocation, useNavigate } from 'react-router-dom';


function ProductByCategory() {

    const [currProducts, setCurrProducts] = useState();
    const location = useLocation();
    // const [quantity, setQuantity] = useState(0);
    const data = location.state || { data: { message: 'No data passed' } };

    // const handleIncrement = () => {
    //     setQuantity(prevQuantity => prevQuantity + 1);
    // };

    // const handleDecrement = () => {
    //     setQuantity(prevQuantity => (prevQuantity > 0 ? prevQuantity - 1 : 0));
    // };

    // const handleSubmit = () => {
    //     alert(`Submitted quantity: ${quantity}`);
    //     // Replace with your submit function
    // };


    const handleRedirect = (prop) => {
        console.log(prop)
        const selectedId = prop;
        navigate('/product', { state: selectedId });
    }
    const navigate = useNavigate();

    useEffect(() => {
        const fetchProducts = async () => {
            console.log(data)
            try {
                const response = await axios.get(`https://localhost:7185/api/Product/bycategory/${data}`)
                setCurrProducts(response.data)
                console.log(response.data)
            }
            catch (e) {
                console.log(e)
            }
        }
        fetchProducts()
    }, [])
    console.log(currProducts)
    return (
        <div class="home-main-container">
            <Navbar />
            <div className='home-sub-container'>
                <Searchbar />
                <div className='products-main-container'>
                    {
                        currProducts?.map((item,index) => (
                            // <div
                            //     key={currProducts.index}
                            //     className='category-card'
                            //     style={{ background: `url(${img1}) no-repeat center center`,backgroundSize: 'cover'}}
                            //     onClick={()=>{handleRedirect(item.productId)}}
                            // >
                            //     <span>{item.productName}</span>

                            // </div>
                            <div
                                className="product-card"
                                style={{
                                    justifySelf: index % 2 === 0 ? 'flex-end' : 'flex-start'
                                }}
                                onClick={() => { handleRedirect(item.productId) }}
                            >
                                <img src={`data:image/jpeg;base64,${item.images}`} className="product-card-image"/>
                                <div className="product-card-body">
                                    <h2 className="product-card-title">{item.productName}</h2>
                                    <p className="product-card-price">₹{item.price}</p>
                                    <div className="product-card-rating">
                                        <span className="product-star">★</span>
                                        <span className="product-star">★</span>
                                        <span className="product-star">★</span>
                                        <span className="product-star">★</span>
                                        <span className="product-star">☆</span>
                                    </div>
                                    {/* <div className="product-quantity-controls">
                                        <button className="product-quantity-btn" onClick={handleDecrement}>-</button>
                                        <input type="text" value={quantity} readOnly className="product-quantity-input" />
                                        <button className="product-quantity-btn" onClick={handleIncrement}>+</button>
                                    </div>
                                    <button className="product-submit-btn" onClick={handleSubmit}>Submit</button> */}
                                </div>
                            </div>

                        ))
                    }
                </div>
            </div>
        </div>
    )
}

export default ProductByCategory
