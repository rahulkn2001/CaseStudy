import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import "./login.css";
import main_logo from "../assets/images/main-logo.jpeg";
import banner_img from "../assets/images/banner.svg";
import Register from "./register";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';


import Address from './Address';

const Login = () => {
  // State hooks for userid and password
  const [Email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [oldUser, setOldUser] = useState(true)
  const [error, seterror] = useState('problem creates error');
  const navigate = useNavigate();
  // Handler for password input change
  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  // Handler for form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
    console.log('Submitted:', { Email, password });
    callapi(Email, password)

  };
  async function callapi(Email, password) {
    try {
      const response = await axios.post('https://localhost:7082/authenticate',
        { Email: Email, upassword: password, Firstname: 'John' },
        { headers: { 'Content-Type': 'application/json' } }
      );
      console.log(response.data)
      const token = response.data.token;
      const userid = response.data.userId;
      console.log(token, '------', userid);
      localStorage.setItem('token', token);
      localStorage.setItem('userid', userid);
      navigate('/homepage');
    } catch (error) {
      seterror('Invalid username or password');
    }
  }


  return (
    <div className='main-container'>
      <div className='banner-container'>
        <img className='banner-img' src={banner_img} />
      </div>

      <div className='login-container'>
        {/* <div>Login</div>
      
      <form onSubmit={handleSubmit}>
        <label>
          Email
          <input
            type="text"
            name="Email"
            value={Email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
        <br />
        <label>
          Password
          <input
            type="password"
            name="password"
            value={password}
            onChange={handlePasswordChange}
          />
        </label>
        <br />
        <button type="submit">Submit</button>
      </form> */}


        <h1 className="login-title">Login</h1>
        <form className="login-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="Email"
              value={Email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="login-button">Log In</button>
        </form>
        <div style={{ padding: "20px" }}>
          New User? <span onClick={() => { navigate('/register') }} style={{color:"green", cursor:"pointer"}}>Sign up HERE</span>
        </div>
      </div>
    </div>
  );
};

export default Login;
