import React, { useEffect, useState } from 'react'
import Navbar from './Navbar';
import "./Category.css"
import axios from 'axios';
// import img1 from "../assets/Categories/1.png"
import { useNavigate } from 'react-router';

import Searchbar from './Searchbar';


function Category() {

    const [categories, setCategories] = useState()
    const navigate = useNavigate();

    const handleRedirect = (prop) => {
        // console.log(prop)
        const selectedCategory = prop;
        navigate('/productbycategory', { state: selectedCategory });
    }

    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const response = await axios.get(`https://localhost:7185/api/Product/categoriesAll`)
                setCategories(response.data)
            }
            catch (e) {
                console.log(e)
            }
        }
        fetchCategories()
    }, [])
    // const data =[
    //     {
    //         "categoryId": 1,
    //         "categoryName": "Electronics",
    //         "products": []
    //     },
    //     {
    //         "categoryId": 2,
    //         "categoryName": "Books",
    //         "products": []
    //     },
    //     {
    //         "categoryId": 3,
    //         "categoryName": "Clothing",
    //         "products": []
    //     },
    //     {
    //         "categoryId": 4,
    //         "categoryName": "Home Appliances",
    //         "products": []
    //     },
    //     {
    //         "categoryId": 5,
    //         "categoryName": "Toys",
    //         "products": []
    //     },
    //     {
    //         "categoryId": 6,
    //         "categoryName": "Sports Equipment",
    //         "products": []
    //     },
    //     {
    //         "categoryId": 7,
    //         "categoryName": "furniture",
    //         "products": []
    //     }
    // ]
    console.log(categories)
    return (
        <div class="home-main-container">
            <Navbar />
            <div className='home-sub-container'>
                <Searchbar />
                <div className='category-main-container'>
                    {
                        categories?.map((item) => (
                            // <div
                            // key = {item.categoryId}
                            // className='category-card'
                            // style={{background: `url(${img1}) no-repeat center center`,backgroundSize: 'cover'}}
                            // onClick={()=>{handleRedirect(item.categoryName)}}
                            // >
                            //     <span style={{fontSize:'15px',color:'white'}}>{item.categoryName}</span>

                            // </div>
                            <div 
                            class="category-card" 
                            style={{background: `url(/Categories/${item.categoryId}.png) no-repeat`,backgroundSize: 'cover'}}
                            onClick={()=>{handleRedirect(item.categoryName)}}
                            >
                                <div class="category-card-content">
                                    <h2 class="category-card-title">{item.categoryName}</h2>
                                </div>
                            </div>

                        ))
                    }
                </div>
            </div>
        </div>
    )
}

export default Category
