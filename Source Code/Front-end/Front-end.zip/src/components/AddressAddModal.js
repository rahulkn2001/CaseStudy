// AddressAddModal.js
import React, { useState } from 'react';
import './AddressAddModal.css'; // Add CSS for styling the modal


const AddressAddModal = ({ isOpen, onRequestClose, onSave }) => {
  const userid = localStorage.getItem('userid');
  const [newAddress, setNewAddress] = useState({
    userid:userid,
    houseNumber: '',
    addressline1: '',
    addressline2: '',
    city: '',
    state: '',
    zipcode: ''
  });
  
  const handleChange = (e) => {
    setNewAddress({ ...newAddress, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    onSave(newAddress);
    setNewAddress({
      userid:userid,
      houseNumber: '',
      addressline1: '',
      addressline2: '',
      city: '',
      state: '',
      zipcode: ''
    });
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onRequestClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <h2>Add Address</h2>
        <label>House Number:</label>
        <input
          type="text"
          name="houseNumber"
          value={newAddress.houseNumber}
          onChange={handleChange}
        />
        <label>Address Line 1:</label>
        <input
          type="text"
          name="addressline1"
          value={newAddress.addressline1}
          onChange={handleChange}
        />
        <label>Address Line 2:</label>
        <input
          type="text"
          name="addressline2"
          value={newAddress.addressline2}
          onChange={handleChange}
        />
        <label>City:</label>
        <input
          type="text"
          name="city"
          value={newAddress.city}
          onChange={handleChange}
        />
        <label>State:</label>
        <input
          type="text"
          name="state"
          value={newAddress.state}
          onChange={handleChange}
        />
        <label>Zipcode:</label>
        <input
          type="text"
          name="zipcode"
          value={newAddress.zipcode}
          onChange={handleChange}
        />
        <div className="modal-actions">
          <button onClick={handleSubmit}>Save</button>
          <button onClick={onRequestClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
};

export default AddressAddModal;
