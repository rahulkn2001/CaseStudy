import React, { useEffect, useState } from 'react';
import axios from 'axios';
import "./UserProfile.css"
import profileart from "../assets/images/editprofileart.jpg"

const UserProfile1 = () => {
  const [user, setUser] = useState({
    userId: null,
    firstname: '',
    lastname: '',
    email: '',
    upassword: ''
  });
  const [editMode, setEditMode] = useState(false);
  const [error, setError] = useState('');

  const userid = localStorage.getItem('userid');
  const token = localStorage.getItem('token');

  useEffect(() => {
    if (!userid || !token) {
      setError('User not authenticated.');
      return;
    }

    const fetchUserData = async () => {
      try {
        const response = await axios.get(`https://localhost:7082/authenticate/${userid}`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        setUser(response.data);
      } catch (err) {
        console.error('Error fetching user data:', err);
        setError('Failed to fetch user data.');
      }
    };

    fetchUserData();
  }, [userid, token]); // Add dependencies

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSave = async () => {
    try {
      await axios.put(`https://localhost:7082/authenticate/${userid}`, user, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      alert('Successfully Updated')
      setEditMode(false);
    } catch (err) {
      console.error('Error updating user data:', err);
      setError('Failed to update profile. Please try again.');
    }
  };

  return (
    // <div className="profile-container">
    //   <h2>User Profile</h2>
    //   {error && <div className="error-message">{error}</div>}
    //   <div className="profile-form">
    //     <label>
    //       First Name:
    //       <input
    //         type="text"
    //         name="firstname"
    //         value={user.firstname}
    //         onChange={handleChange}
    //         disabled={!editMode}
    //       />
    //     </label>
    //     <label>
    //       Last Name:
    //       <input
    //         type="text"
    //         name="lastname"
    //         value={user.lastname}
    //         onChange={handleChange}
    //         disabled={!editMode}
    //       />
    //     </label>
    //     <label>
    //       Email:
    //       <input
    //         type="email"
    //         name="email"
    //         value={user.email}
    //         onChange={handleChange}
    //         disabled={!editMode}
    //       />
    //     </label>
    //     <label>
    //       Password:
    //       <input
    //         type="password"
    //         name="upassword"
    //         value={user.upassword}
    //         onChange={handleChange}
    //         disabled={!editMode}
    //       />
    //     </label>
    //     {editMode ? (
    //       <div>
    //         <button onClick={handleSave}>Save</button>
    //         <button onClick={() => setEditMode(false)}>Cancel</button>
    //       </div>
    //     ) : (
    //       <button onClick={() => setEditMode(true)}>Edit</button>
    //     )}
    //   </div>
    // </div>

    
    <div class="profile-main-container">
      <div class="profile-sub-container">
        <div className="profile-title">EDIT PROFILE</div>
        {error && <div className="error-message">{error}</div>}
        <svg className="profile-photo" xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
          <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0" />
          <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1" />
        </svg>
        <div className="login-form">
          <div className="form-group profile-form">
            <label>
              First Name:
              <input
                type="text"
                name="firstname"
                value={user.firstname}
                onChange={handleChange}
                disabled={!editMode}
              />
            </label>
            <label>
              Last Name:
              <input
                type="text"
                name="lastname"
                value={user.lastname}
                onChange={handleChange}
                disabled={!editMode}
              />
            </label>
            <label>
              Email:
              <input
                type="email"
                name="email"
                value={user.email}
                onChange={handleChange}
                disabled={!editMode}
              />
            </label>
            <label>
              Password:
              <input
                type="password"
                name="upassword"
                value={user.upassword}
                onChange={handleChange}
                disabled={!editMode}
              />
            </label>
            {editMode ? (
              <div>
                <button onClick={handleSave}>Save</button>
                <button onClick={() => setEditMode(false)}>Cancel</button>
              </div>
            ) : (
              <button onClick={() => setEditMode(true)}>Edit</button>
            )}
          </div>

        </div>


      </div>
    </div>
  );
};

export default UserProfile1;
