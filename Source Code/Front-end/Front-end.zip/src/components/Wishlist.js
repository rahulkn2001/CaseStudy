import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import Searchbar from './Searchbar';
import './Wishlist.css';

const Wishlist = () => {
  const [wishlistItems, setWishlistItems] = useState([]);
  const [error, setError] = useState(null);
  const [quantity, setQuantity] = useState(1);

  const userId = localStorage.getItem('userid');


  const fetchProductDetails = async (productId) => {
    try {
      const response = await axios.get(`https://localhost:7185/api/Product/products/${productId}`); // Replace with your actual API endpoint
      return response.data;
    } catch (error) {
      console.error('Error fetching product details:', error);
      return null;
    }
  };

  const removeFromWishlist = async (productId) => {
    try {
      await axios.delete(`https://localhost:7174/api/WishlistItems/${userId}/${productId}`, {
        headers: {
          'Accept': '*/*',
          'Content-Type': 'application/json'
        }
      });
      fetchWishlistItems();
    } catch (error) {
      console.error('Error removing from wishlist:', error);
    }
  };

  const addToCart = async (productId) => {
    alert(`Product Added to Cart`);
    const userId = localStorage.getItem('userid');
    try {
        const response = await axios.post('https://localhost:7185/api/Cart/add', {
            userId: userId,
            productId: productId,
            quantity: quantity
        }, {
            headers: {
                'Accept': '*/*',
                'Content-Type': 'application/json'
            }
        });
        console.log('Response:', response.data);
        await removeFromWishlist(productId);
    } catch (error) {
        console.error('Error adding to cart:', error);
    }
    setQuantity(1);
};

const fetchWishlistItems = async () => {
  try {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userid');

    if (!userId) {
      setError('User ID is missing.');
      return;
    }

    const response = await axios.get(`https://localhost:7174/api/WishlistItems/user/${userId}`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    console.log(response.data); // Log the response to check the structure
    const itemsWithDetails = await Promise.all(response.data.wishlistItems.map(async (item) => {
      const productDetails = await fetchProductDetails(item.productId);
      return {
        ...item,
        ...productDetails
      };
    }));

    setWishlistItems(itemsWithDetails);
    setError(null);
  } catch (err) {
    setError('Failed to fetch wishlist items.');
    setWishlistItems([]); // Set empty array in case of an error
  }
};

  

  useEffect(() => {
    fetchWishlistItems();
  }, []);

  return (    
      <div class="home-main-container">
          <Navbar />
          <div className='home-sub-container'>
              <Searchbar />
              <div className="wishlist-content">
              <div className="wishlist-items">
              {error && <p style={{ color: 'red' }}>{error}</p>}
                   {wishlistItems.length > 0 ? (
  wishlistItems.map((item) => (
    <div className="wishlist-item-card" key={item.productId}>
      <img src={`data:image/jpeg;base64,${item.images}`} alt={item.productName} className="wishlist-item-image" />
      {/* <img className='wishlist-item-image' src={`data:image/jpeg;base64,${item?.images}`} alt="Product" /> */}
      <div className="wishlist-item-info">
        <div className="wishlist-item-name">{item.productName}</div>
        <div className="wishlist-item-subtext">Price: {item.price}</div>
        <div className="wishlist-item-actions">
          <button className="wishlist-add-to-cart" onClick={() => addToCart(item.productId)}>Add to Cart</button>
          <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="darkred" className="bi bi-trash-fill wishlist-delete-icon" viewBox="0 0 16 16" onClick={() => removeFromWishlist(item.productId)}>
            <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5M8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5m3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0" />
          </svg>
        </div>
      </div>
    </div>
  ))
) : (
           <p>No items in your wishlist</p>
         )}
</div>

      </div>
          </div>
      </div>
  );
};

export default Wishlist;
