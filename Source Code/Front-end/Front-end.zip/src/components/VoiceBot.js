import React, { useState } from 'react';
import './voicebot.css'

const VoiceBot = () => {
  const [question, setQuestion] = useState('');
  const [response, setResponse] = useState('');
  const [isListening, setIsListening] = useState(false);

  const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = 'en-US';

  const handleStartListening = () => {
    setIsListening(true);
    recognition.start();
  };

  const handleStopListening = () => {
    setIsListening(false);
    recognition.stop();
  };

  recognition.onresult = (event) => {
    const recognizedQuestion = event.results[0][0].transcript;
    setQuestion(recognizedQuestion);
    setResponse('Sorry, we don’t have an answer for this right now. We’ll get back to you later.');
  };

  recognition.onerror = (event) => {
    console.error('Speech recognition error:', event.error);
    setResponse('Error recognizing speech.');
  };

  return (
    <div>
      <button
        className="voice-button"
        onClick={isListening ? handleStopListening : handleStartListening}
      >
        {isListening ? 'Stop Listening' : 'Speak Your Question'}
      </button>
      {question && <p><strong>Your Question:</strong> {question}</p>}
      <p>{response}</p>
    </div>
  );
};

export default VoiceBot;
