import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import Searchbar from './Searchbar';
import { useNavigate } from 'react-router-dom';
import img1 from '../assets/images/main-logo.jpeg'

import './Cart.css'

const Cart = () => {
  const [cartProducts, setCartProducts] = useState([]);
  // const [orderId, setOrderId] = useState();
  const [totalAmount, setTotalAmount] = useState();
  const [error, setError] = useState(null);
  const navigate = useNavigate();


  const placeOrder = async () => {
    setTotalAmount(1.18*totalAmount)
    const userid = localStorage.getItem('userid');
    console.log(totalAmount + " " + cartProducts[0])

    try {
      const response = await axios.post(
        'https://localhost:7041/api/Order',
        {
          userId: userid,
          totalAmount: totalAmount,
          items: cartProducts
        },
        {
          headers: {
            'Accept': '*/*',
            'Content-Type': 'application/json'
          },
          // If you're using self-signed certificates for localhost, you may need to disable SSL validation:
          // `httpsAgent: new https.Agent({ rejectUnauthorized: false })` (use with caution)
        }
      );
      // setOrderId(response.data.orderId)
      console.log('Response:', response.data);
      console.log(response.data.orderId)
      const orderId = response.data.orderId
      console.log(orderId)
      navigate('/payment', {
        state: { orderId, totalAmount, cartProducts }
      });
    } catch (error) {
      console.error('Error:', error);
    }
    // window.location.reload();


  };


  const deleteFromCart = async (prop1, prop2) => {
    console.log("clicked " + prop1 + " " + prop2)
    //   try {
    //     const response = await axios.delete('https://localhost:7185/api/Cart/delete', {
    //       cartId: userId,
    //       productId: prop
    //     }, {
    //       headers: {
    //         'Accept': '*/*',
    //         'Content-Type': 'application/json'
    //       },

    //     });

    //     console.log('Response:', response.data);
    //   } catch (error) {
    //     console.error('Error deleting from cart:', error);
    //   }
    axios.delete('https://localhost:7185/api/Cart/delete', {
      headers: {
        'Accept': '*/*',
        'Content-Type': 'application/json'
      },
      data: {
        cartId: prop2,
        productId: prop1
      }
    })
      .then(response => {
        console.log('Response:', response.data);
      })
      .catch(error => {
        console.error('Error:', error);
      });

    window.location.reload();
  };

  useEffect(() => {

    const calculateTotalAmount = () => {
      const value = cartProducts?.reduce((total, item) => total + item.price * item.quantity, 0).toFixed(2);
      setTotalAmount(value)
    }
    calculateTotalAmount();
  }, [cartProducts])

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const token = localStorage.getItem('token');
        const userId = localStorage.getItem('userid');

        if (!userId) {
          setError('User ID is missing.');
          return;
        }

        // const response = await axios.get(`https://localhost:7174/api/Cart/${userId}`, {
        //   headers: {
        //     Authorization: `Bearer ${token}`
        //   }
        const response = await axios.get(`https://localhost:7185/api/Cart/items/${userId}`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        setCartProducts(response.data);
        setError(null);
      } catch (err) {
        setError('Failed to fetch products.');
        setCartProducts([]);
      }
    };

    // Fetch products when component mounts
    fetchProducts();
    // setTimeout(() => {      
    //   calculateTotalAmount();
    // }, 2000);
  }, []);

  console.log(cartProducts)
  return (
    // <div>
    //   <h1>Product List</h1>
    //   {error && <p style={{ color: 'red' }}>{error}</p>}
    //   <ul>
    //     {productNames.length > 0 ? (
    //       productNames.map((name, index) => <li key={index}>{name}</li>)
    //     ) : (
    //       <p>No products found</p>
    //     )}
    //   </ul>
    // </div>
    <div class="home-main-container">
      <Navbar />
      <div className='home-sub-container'>
        <Searchbar />
        <div className='cart-main-container'>
          <div className='cart-items-container'>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            {cartProducts.length > 0 ? (
              cartProducts.map((item, index) => (
                <div className="cart-item-card">
                  <img src={`data:image/jpeg;base64,${item.productimages}`} alt={item.productName} className="cart-item-image" />
                  <div className="cart-item-info">
                    <div className="cart-item-name">{item.productName}</div>
                    <div className="cart-item-subtext">Price: {item.price}</div>
                    <div className="cart-item-subtext">Quantity: {item.quantity}</div>
                    <div className="cart-item-subtext">Amount: {item.quantity * item.price}</div>
                  </div>
                  <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="darkred" class="bi bi-trash-fill cart-delete-icon" viewBox="0 0 16 16" onClick={() => { deleteFromCart(item.productId, item.cartId) }}>
                    <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5M8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5m3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0" />
                  </svg>
                </div>

              ))
            ) : (
              <p>No products found</p>
            )}


          </div>
          <div className='cart-summary-container'>
            <div className='cart-summary-title'>
              Order Summary
            </div>
            <div className='cart-summary-details'>
              <div class="cart-summary-item">
                <span class="cart-summary-label">Total taxable:</span>
                <span class="cart-summary-value">{totalAmount}</span>
              </div>
              <div class="cart-summary-item">
                <span class="cart-summary-label">GST:</span>
                <span class="cart-summary-value">{totalAmount*0.18}.00</span>
              </div>
              <div class="cart-summary-item">
                <span class="cart-summary-label">Delivery Charges:</span>
                <span class="cart-summary-value">Free!</span>
              </div>
              <div class="cart-summary-item">
                <span class="cart-summary-label">Total Amount:</span>
                <span class="cart-summary-value">{totalAmount*1.18}.00</span>
              </div>

            </div>
            <button className='cart-payment-button' onClick={placeOrder}>PAY NOW</button>
          </div>
        </div>
      </div>

    </div>
  );
};

export default Cart;
