import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Navbar.css';

const Navbar = () => {
  const [categories, setCategories] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const [navExtended, setNavExtended] = useState('false');
  const [navWidth, setNavWidth] = useState("60px")

  const navigate = new useNavigate();

  // useEffect(() => {
  //   const fetchCategories = async () => {
  //     try {
  //       const res = await axios.get('https://localhost:7174/api/Category');
  //       setCategories(res.data);
  //     } catch (error) {
  //       console.log(error);
  //     }
  //   };

  //   fetchCategories();
  // }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userid');
    navigate('/')
  }


  const handleInputChange = (event) => {
    setSearchTerm(event.target.value);
    setDropdownVisible(true);
  };

  const handleOptionClick = (category) => {
    setSearchTerm(category.categoryName);
    setDropdownVisible(false);
  };

  const handleClickOutside = (event) => {
    if (!event.target.closest('.dropdown-container')) {
      setDropdownVisible(false);
    }
  };

  const handleNavChange = () => {
    console.log("mesf")
    setNavExtended(!navExtended);
    if (navExtended == false) {
      setNavWidth("60px")
    }
    else {
      setNavWidth("350px")
    }
  }

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    // <nav>
    //   <ul>
    //     <li><Link to="/address">Address</Link></li>
    //     <li><Link to="/cart">Cart</Link></li>
    //     <li><Link to="/orders">Orders</Link></li>
    //   </ul>
    //   <div className="position-relative dropdown-container">
    //     <input
    //       className="form-control me-2"
    //       type="text"
    //       placeholder="Search"
    //       value={searchTerm}
    //       onChange={handleInputChange}
    //       onClick={() => setDropdownVisible(true)}
    //     />
    //     {dropdownVisible && (
    //       <div className="position-absolute w-100 mt-1 bg-white border rounded shadow">
    //         {categories
    //           .filter(category => category.categoryName.toLowerCase().includes(searchTerm.toLowerCase()))
    //           .map(category => (
    //             <div
    //               key={category.categoryId}
    //               className="p-2 cursor-pointer"
    //               onClick={() => handleOptionClick(category)}
    //             >
    //               {category.categoryName}
    //             </div>
    //           ))}
    //         {categories.filter(category => category.categoryName.toLowerCase().includes(searchTerm.toLowerCase())).length === 0 && (
    //           <div className="p-2 text-muted">No results</div>
    //         )}
    //       </div>
    //     )}
    //     <button className="btn btn-outline-success mt-2" type="submit">Search</button>
    //   </div>
    //   <Link to="/userprofile" className="profile-link">
    //     <div className="profile-circle">

    //       <span className="profile-icon">👤</span> 
    //     </div>
    //   </Link>
    // </nav>

    <div class="nav-main-container" style={{ width: navWidth }}>
      {
        navExtended ? (
          <>
            <div class="nav-subcontainer-1" onClick={() => { handleNavChange() }}>
              <svg className="nav-menu-icon" xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="white" class="bi bi-list nav-icons" viewBox="0 0 16 16" >
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5" />
              </svg>
            </div>
            <div className='nav-subcontainer-2'>
              <Link to="/homepage">
                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="white" class="bi bi-house-fill nav-icons" viewBox="0 0 16 16" >
                  <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293z" />
                  <path d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293z" />
                </svg>
              </Link>
              <Link to="/category">
                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="white" class="bi bi-card-list nav-icons" viewBox="0 0 16 16">
                  <path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2z" />
                  <path d="M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8m0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5m0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5m-1-5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0M4 8a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0m0 2.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0" />
                </svg>
              </Link>
              <Link to="/cart">
                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="white" class="bi bi-cart-fill nav-icons" viewBox="0 0 16 16" >
                  <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
                </svg>
              </Link>
              <Link to="/orderhistory">
                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="white" class=" nav-icons" viewBox="0 0 32 32" id="order-history">
                  <path d="M9,9a1,1,0,0,1,1-1h4a1,1,0,0,1,0,2H10A1,1,0,0,1,9,9Zm8,3H10a1,1,0,0,0,0,2h7a1,1,0,0,0,0-2Zm0,4H10a1,1,0,0,0,0,2h7a1,1,0,0,0,0-2ZM30,8a5.984,5.984,0,0,1-8,5.65V27a3,3,0,0,1-3,3H6a3,3,0,0,1-3-3V25a1,1,0,0,1,1-1H5V6A4,4,0,0,1,9,2H21a.983.983,0,0,1,.8.425A5.988,5.988,0,0,1,30,8ZM6,28H16.184A2.966,2.966,0,0,1,16,27V26H5v1A1,1,0,0,0,6,28ZM20,12.46A5.969,5.969,0,0,1,19.54,4H9A2,2,0,0,0,7,6V24H17a1,1,0,0,1,1,1v2a1,1,0,0,0,2,0ZM28,8a4,4,0,1,0-4,4A4,4,0,0,0,28,8ZM26,7H25a1,1,0,0,0-2,0V8a1,1,0,0,0,1,1h2a1,1,0,0,0,0-2Z"></path>
                </svg>
              </Link>
              <Link to="/wishlist">
                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="white" class="bi bi-star-fill nav-icons" viewBox="0 0 16 16">
                  <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
                </svg>
              </Link>
            </div>
            <div className='nav-subcontainer-3' onClick={handleLogout}>
              <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="white" class="bi bi-box-arrow-left nav-icons" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M6 12.5a.5.5 0 0 0 .5.5h8a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-8a.5.5 0 0 0-.5.5v2a.5.5 0 0 1-1 0v-2A1.5 1.5 0 0 1 6.5 2h8A1.5 1.5 0 0 1 16 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-8A1.5 1.5 0 0 1 5 12.5v-2a.5.5 0 0 1 1 0z" />
                <path fill-rule="evenodd" d="M.146 8.354a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L1.707 7.5H10.5a.5.5 0 0 1 0 1H1.707l2.147 2.146a.5.5 0 0 1-.708.708z" />
              </svg>
            </div>
          </>
        ) :
          (
            <>
              <div class="nav-subcontainer-1" onClick={() => { handleNavChange() }}>
                <svg className="nav-menu-icon" xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="red" class="bi bi-list" viewBox="0 0 16 16">
                  <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5" />
                </svg>
              </div>
              <div className='nav-subcontainer-2'>
                <div className='nav-text-options' >
                  <Link to="/homepage" style={{ color: 'white', textDecoration: 'none' }}>
                    Home
                  </Link>
                </div>
                <div className='nav-text-options' >
                  <Link to="/category" style={{ color: 'white', textDecoration: 'none' }}>
                    Catalog
                  </Link>
                </div>
                <div className='nav-text-options' >
                  <Link to="/cart" style={{ color: 'white', textDecoration: 'none' }}>
                    Cart
                  </Link>
                </div>
              </div>

            </>
          )
      }

    </div>

  );
};

export default Navbar;
