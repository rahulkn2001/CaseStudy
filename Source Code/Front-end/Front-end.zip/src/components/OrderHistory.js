import React, { useEffect, useState } from 'react'
import axios from 'axios';
import Navbar from './Navbar';
import Searchbar from './Searchbar';
import "./Orderhisroy.css"

function OrderHistory() {

    const [mergedOrders, setMergedOrders] = useState();
    const [selectedOrder, setSelectedOrder] = useState();
    const [orders, setOrders] = useState(null);

    const formatDate = (dateString) => {
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return new Date(dateString).toLocaleDateString(undefined, options);
    };

    // const mergeOrders = (data) => {
    //     const mergedData = {};

    //     data.forEach(item => {
    //         const { orderId, productName, price } = item;

    //         if (!mergedData[orderId]) {
    //             mergedData[orderId] = {
    //                 orderId,
    //                 products: [],
    //                 totalAmount: 0,
    //                 orderDate: item.orderDate,
    //                 status: item.status,
    //             };
    //         }

    //         mergedData[orderId].products.push({ productName, price });
    //         mergedData[orderId].totalAmount += price;
    //     });
    //     setOrders(mergedData)
    //     console.log("info")
    //     console.log(mergedData)

    // };

    // const mergeOrders = () => {
    //     const mergedOrders = orders?.reduce((acc, order) => {
    //         // Find the index of the orderId in the accumulator
    //         const index = acc.findIndex(o => o.orderId === order.orderId);

    //         if (index === -1) {
    //             // If orderId not found, add a new entry
    //             acc.push({
    //                 ...order,
    //                 products: [{ productName: order.productName, price: order.price }]
    //             });
    //         } else {
    //             // If orderId found, append the product to the products array
    //             acc[index].products.push({ productName: order.productName, price: order.price });
    //         }

    //         return acc;
    //     }, []);
    //     console.log("info1")
    //     console.log(orders)
    //     setOrders(mergedOrders)
    //     console.log(orders)

    // }
    const handleOrderClick = (data) =>{
        // if (selectedOrder === data)
        // {
        //     selectedOrder(null)
        // }
        // else{

            console.log("clicked")
            setSelectedOrder(data)
            console.log(selectedOrder)
        // }
    }


    const mergeOrders = () => {
        const mergedOrders = [];
        console.log(orders)

        // Iterate over each order
        orders?.forEach(order => {
            const { orderId, productName, price, orderDate, status } = order;

            // If the orderId doesn't exist in mergedOrders, initialize it
            if (!mergedOrders[orderId]) {
                mergedOrders[orderId] = {
                    orderId,
                    products: [],
                    orderDate,
                    status
                };
            }

            // Add the product to the corresponding orderId
            mergedOrders[orderId].products.push({
                productName,
                price
            });
        });

        // Convert the mergedOrders object to an array of values

        // Convert the mergedOrders object to an array of values
        // setOrders(mergedOrders);
        console.log("rahul")
        console.log(mergedOrders)
        const reversedItems = [...mergedOrders].reverse();
        console.log(reversedItems)
        setMergedOrders(mergedOrders)
    }

    // const mergeFun = () =>{
    //     const arrayHashmap = orders?.reduce((obj, item) => {
    //         obj[item.id] ? obj[item.id].elements.push(...item.elements) : (obj[item.id] = { ...item });
    //         return obj;
    //       }, {});
    //       console.log(arrayHashmap);
    // }

    useEffect(() => {
        mergeOrders()
    }, [orders])




    useEffect(() => {
        const fetchOrders = async () => {
            const userId = localStorage.getItem('userid');
            try {
                const response = await axios.get(`https://localhost:7041/api/Order/${userId}`)
                setOrders(response.data)
            }
            catch (e) {
                console.log(e)
            }
        }
        fetchOrders()
    }, [])
    console.log(orders)

    return (
        <div class="home-main-container">
            <Navbar />
            <div className='home-sub-container'>
                <Searchbar />
                <div className="order-container">
                    <h1>Order History</h1>
                    <div className="order-history">
                        {mergedOrders?.map((order) => (
                            //   <OrderCard key={order.id} order={order} />
                            <div 
                            className={`order-card order-${order.status}`} 
                            key={order.orderId}
                            onClick={() => {handleOrderClick(order)}}
                            >
                                <h2>Order #{order.orderId}</h2>
                                <p><strong>Date: </strong> {formatDate(order.orderDate)}</p>
                                <p><strong>Status: </strong> {order.status}</p>
                                {/* <p><strong>Total Amount: </strong> {order.price}</p> */}
                                {selectedOrder?.orderId===order.orderId ? (
                                    <div className="order-details">
                                        <ul>
                                            {selectedOrder?.products.map((product, index) => (
                                                <li key={index}>
                                                    <p><strong>Product Name:</strong> {product.productName}</p>
                                                    <p><strong>Price:</strong> {product.price}</p>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                    ):
                                    
                                (<></>)}
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    )
}

export default OrderHistory


