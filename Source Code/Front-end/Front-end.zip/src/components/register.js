// import React, { useState } from 'react';
// import { useNavigate, } from 'react-router-dom';
// import banner_img from "../assets/images/banner.svg";
// import "./login.css";
// import axios from 'axios';

// const Login = () => {
//   // State hooks for user input
//   const [password, setPassword] = useState('12345');
//   const [email, setemail] = useState('sudhanvagv44@gmail.com');
//   const [firstname, setfirstname] = useState('sudhanva');
//   const [lastname, setlastname] = useState('gv');

//   // State hooks for error and success messages
//   const [error, seterror] = useState('');
//   const [successMessage, setSuccessMessage] = useState('');

//   const navigate = useNavigate();

//   // Handlers for input changes
//   const handlePasswordChange = (e) => setPassword(e.target.value);
//   const handleFirstnameChange = (e) => setfirstname(e.target.value);
//   const handleLastnameChange = (e) => setlastname(e.target.value);
//   const handleEmailChange = (e) => setemail(e.target.value);

//   // Handler for form submission
//   const handleSubmit = (e) => {
//     e.preventDefault();
//     console.log('Submitted:', { password, firstname, email, lastname });
//     callApi(password, firstname, email, lastname);
    
//   };

//   // API call for registration
//   async function callApi(password, firstname, email, lastname) {
//     try {
//       const response = await axios.post('https://localhost:7137/api/Register/register',
//         { upassword: password, Firstname: firstname, Email: email, Lastname: lastname },
//         { headers: { 'Content-Type': 'application/json' } }
//       );

//       setSuccessMessage('Registration successful. Please check your email for verification.');
//       navigate('/');
//     } catch (error) {
//       seterror('Registration failed: ' + (error.response?.data || error.message));
//     }
    
//   }

//   return (
//     // <div>
//     //   <div>Login</div>

//     //   <form onSubmit={handleSubmit}>
//     //     <label>
//     //       Password
//     //       <input
//     //         type="password"
//     //         name="password"
//     //         value={password}
//     //         onChange={handlePasswordChange}
//     //       />
//     //     </label>
//     //     <br />
//     //     <label>
//     //       First name
//     //       <input
//     //         type="text"
//     //         name="firstname"
//     //         value={firstname}
//     //         onChange={handleFirstnameChange}
//     //       />
//     //     </label>
//     //     <br />
//     //     <label>
//     //       Last name
//     //       <input
//     //         type="text"
//     //         name="lastname"
//     //         value={lastname}
//     //         onChange={handleLastnameChange}
//     //       />
//     //     </label>
//     //     <br />
//     //     <label>
//     //       Email
//     //       <input
//     //         type="text"
//     //         name="email"
//     //         value={email}
//     //         onChange={handleEmailChange}
//     //       />
//     //     </label>
//     //     <br />
//     //     <button type="submit">Submit</button>
//     //   </form>

//     //   {error && <div className="error">{error}</div>}
//     //   {successMessage && <div className="success">{successMessage}</div>}
//     // </div>
//     <div className='main-container'>
//     <div className='banner-container'>
//       <img className='banner-img' src={banner_img} />
//     </div>
//     <div className='login-container' >
//     <h1 className="login-title">Sign Up</h1>

//       <form className="register-form" onSubmit={handleSubmit}>
//         <div className="form-group">
//           <label >First Name:</label>
//           <input
//             type="text"
//             id="Email"
//             // value={Email}
//             // onChange={(e) => setEmail(e.target.value)}
//             name="firstname"
//             value={firstname}
//             onChange={handleFirstnameChange}
//             required
//           />
//         </div>
//         <div className="form-group">
//           <label >Last Name:</label>
//           <input
//             // type="password"
//             // id="password"
//             // // value={password}
//             // onChange={(e) => setPassword(e.target.value)}
//             type="text"
//             name="lastname"
//             value={lastname}
//             onChange={handleLastnameChange}
//             required
//           />
//         </div>
//         <div className="form-group">
//           <label >Email:</label>
//           <input
//             // type="text"
//             // name="lastname"
//             // value={lastname}
//             // onChange={handleLastnameChange}
//             type="text"
//             name="email"
//             value={email}
//             onChange={handleEmailChange}
//             required
//           />
//         </div>
//         <div className="form-group">
//           <label >Password:</label>
//           <input
//             // type="text"
//             // name="email"
//             // value={email}
//             // onChange={handleEmailChange}
//             type="password"
//             name="password"
//             value={password}
//             onChange={handlePasswordChange}
//             required
//           />
//         </div>
//         <button type="submit" className="login-button">Register</button>
//       </form>

//       <div style={{padding:"20px"}}>
//         Already have an account? <span onClick={()=>{navigate('/')}} style={{color:"green", cursor:"pointer"}}>Sign in HERE</span>
//       </div>
//     </div>
// </div>
//   );
// };

// export default Login;



















import React, { useReducer, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import banner_img from "../assets/images/banner.svg";
import axios from 'axios';
// Initial state and reducer function for userId
const initialState = {
  userId: null,
};
const userReducer = (state, action) => {
  switch (action.type) {
    case 'SET_USER_ID':
      return { ...state, userId: action.payload };
    default:
      return state;
  }
};
const Register = () => {
  // State hooks for user input
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [firstname, setFirstname] = useState('');
  const [lastname, setLastname] = useState('');
  // State hooks for error and success messages
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  // useReducer for managing userId
  const [state, dispatch] = useReducer(userReducer, initialState);
  const navigate = useNavigate();
  // Handlers for input changes
  const handlePasswordChange = (e) => setPassword(e.target.value);
  const handleFirstnameChange = (e) => setFirstname(e.target.value);
  const handleLastnameChange = (e) => setLastname(e.target.value);
  const handleEmailChange = (e) => setEmail(e.target.value);
  // Handler for form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Submitted:', { password, firstname, email, lastname });
    callApi(password, firstname, email, lastname);
  };
  // API call for registration
  async function callApi(password, firstname, email, lastname) {
    try {
      const response = await axios.post('https://localhost:7137/api/Register/register',
        { upassword: password, Firstname: firstname, Email: email, Lastname: lastname },
        { headers: { 'Content-Type': 'application/json' } }
      );
      const res = response.data;
      dispatch({ type: 'SET_USER_ID', payload: res.userId });
      console.log(response.data);
      console.log(res.userId);
      setSuccessMessage('Registration successful. Please check your email for verification.');
      navigate('/verifyotp', { state: { userId: res.userId } });
    } catch (error) {
      setError('Registration failed: ' + (error.response?.data || error.message));
    }
  }
  return (
    // <div>
    //   <div>Login</div>
    //   <form onSubmit={handleSubmit}>
    //     <label>
    //       Password
    //       <input
    //         type="password"
    //         name="password"
    //         value={password}
    //         onChange={handlePasswordChange}
    //       />
    //     </label>
    //     <br />
    //     <label>
    //       First name
    //       <input
    //         type="text"
    //         name="firstname"
    //         value={firstname}
    //         onChange={handleFirstnameChange}
    //       />
    //     </label>
    //     <br />
    //     <label>
    //       Last name
    //       <input
    //         type="text"
    //         name="lastname"
    //         value={lastname}
    //         onChange={handleLastnameChange}
    //       />
    //     </label>
    //     <br />
    //     <label>
    //       Email
    //       <input
    //         type="text"
    //         name="email"
    //         value={email}
    //         onChange={handleEmailChange}
    //       />
    //     </label>
    //     <br />
    //     <button type="submit">Submit</button>
    //   </form>
    //   {error && <div className="error">{error}</div>}
    //   {successMessage && <div className="success">{successMessage}</div>}
    // </div>
        <div className='main-container'>
    <div className='banner-container'>
      <img className='banner-img' src={banner_img} />
    </div>
    <div className='login-container' >
    <h1 className="login-title">Sign Up</h1>

      <form className="register-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label >First Name:</label>
          <input
            type="text"
            id="Email"
            // value={Email}
            // onChange={(e) => setEmail(e.target.value)}
            name="firstname"
            value={firstname}
            onChange={handleFirstnameChange}
            required
          />
        </div>
        <div className="form-group">
          <label >Last Name:</label>
          <input
            // type="password"
            // id="password"
            // // value={password}
            // onChange={(e) => setPassword(e.target.value)}
            type="text"
            name="lastname"
            value={lastname}
            onChange={handleLastnameChange}
            required
          />
        </div>
        <div className="form-group">
          <label >Email:</label>
          <input
            // type="text"
            // name="lastname"
            // value={lastname}
            // onChange={handleLastnameChange}
            type="text"
            name="email"
            value={email}
            onChange={handleEmailChange}
            required
          />
        </div>
        <div className="form-group">
          <label >Password:</label>
          <input
            // type="text"
            // name="email"
            // value={email}
            // onChange={handleEmailChange}
            type="password"
            name="password"
            value={password}
            onChange={handlePasswordChange}
            required
          />
        </div>
        <button type="submit" className="login-button">Register</button>
      </form>

      <div style={{padding:"20px"}}>
        Already have an account? <span onClick={()=>{navigate('/')}} style={{color:"blue", cursor:"pointer"}}>Sign in HERE</span>
      </div>
    </div>
</div>
  );
};
export default Register;
