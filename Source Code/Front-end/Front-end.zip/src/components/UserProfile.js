import React, { useEffect, useState } from 'react';
import axios from 'axios';
import AddressAddModal from './AddressAddModal';
import AddressEditModal from './AddressEditModal';
import './UserProfile.css';
import { toast } from 'react-toastify';

const UserProfile = () => {
  const [user, setUser] = useState({
    userId: null,
    firstname: '',
    lastname: '',
    email: '',
    upassword: ''
  });
  const [addresses, setAddresses] = useState([]);
  const [editMode, setEditMode] = useState(false);
  const [error, setError] = useState('');
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [profilePic, setProfilePic] = useState(localStorage.getItem('profilePic') || null);

  const userid = localStorage.getItem('userid');
  const token = localStorage.getItem('token');

  useEffect(() => {
    if (!userid || !token) {
      setError('User not authenticated.');
      return;
    }

    const fetchUserData = async () => {
      try {
        const response = await axios.get(`https://localhost:7082/authenticate/${userid}`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        setUser(response.data);
        console.log('error was here')
        const response2 = await axios.get(`https://localhost:7174/api/Addresses/user/${userid}`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });        
        setAddresses(response2.data);
      } catch (err) {
        console.error('Error fetching user data:', err);
        toast.success('Could not fetch address data: No address found')
        setError('');
      }
    };

    fetchUserData();
  }, [userid, token]);

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSaveProfile = async () => {
    try {
      await axios.put(`https://localhost:7082/authenticate/${userid}`, user, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      // alert('Profile updated successfully');
      toast.success(`Profile Updated Successfully`);
      setEditMode(false);
    } catch (err) {
      console.error('Error updating profile:', err);
      setError('Failed to update profile.');
    }
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result;
        setProfilePic(base64String);
        localStorage.setItem('profilePic', base64String);
      };
      reader.readAsDataURL(file);
    }
  };
  

  const handleAddAddress = () => {
    setIsAddModalOpen(true);
  };

  const handleModalClose = () => {
    setIsAddModalOpen(false);
    setIsEditModalOpen(false);
    setSelectedAddress(null);
  };

  const handleAddAddressSave = async (newAddress) => {
    try {
      await axios.post(`https://localhost:7174/api/Addresses/addaddress`, newAddress, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      // alert('Address added successfully');
      toast.success(`Address added successfully`);
      setAddresses([...addresses, newAddress]);
      handleModalClose();
    } catch (err) {
      console.error('Error adding address:', err);
      setError('Failed to add address.');
    }
  };

  const handleAddressSave = async (updatedAddress) => {
    try {
      await axios.put(
        `https://localhost:7174/api/Addresses/update/${updatedAddress.addressId}/${userid}`,
        updatedAddress,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      
      // alert('Address updated successfully');
      toast.success(`Address updated successfully`);
      setAddresses(addresses.map(address => 
        address.addressId === updatedAddress.addressId ? updatedAddress : address
      ));
      handleModalClose();
    } catch (err) {
      console.error('Error updating address:', err);
      setError('Failed to update address.');
    }
  };

  const handleDeleteAddress = async (addressId) => {
    try {
      await axios.delete(`https://localhost:7174/api/Addresses/delete/${addressId}/${userid}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      // alert('Address deleted successfully');
      toast.success(`Address Deleted successfully`);
      setAddresses(addresses.filter((address) => address.addressId !== addressId));
    } catch (err) {
      console.error('Error deleting address:', err);
      setError('Failed to delete address.');
    }
  };

  const openEditModal = (address) => {
    setSelectedAddress(address);
    setIsEditModalOpen(true);
  };

  return (
    <div className="profile-main-container">
      {error && <div className="error-message">{error}</div>}
      {/* <div className="profile-and-address"> */}
        <div className="profile-sub-container">
          <div className="profile-title">EDIT PROFILE</div>
          {/* {error && <div className="error-message">{error}</div>} */}

          <div className="profile-image-container">
  {profilePic ? (
    <img src={profilePic} alt="Profile" className="profile-image" />
  ) : (
    <div className="default-profile-image">
      <p>No Profile Picture</p>
    </div>
  )}
  <input
    type="file"
    accept="image/*"
    onChange={handleImageUpload}
    id="upload-input"
    className="upload-input"
  />
  <label htmlFor="upload-input" className="upload-button">
    Upload Profile Picture
  </label>
</div>


          <div className="login-card">
            <div className="login-form">
              <label>First Name:</label>
              <input
                type="text"
                name="firstname"
                value={user.firstname}
                onChange={handleChange}
                disabled={!editMode}
              />
              <label>Last Name:</label>
              <input
                type="text"
                name="lastname"
                value={user.lastname}
                onChange={handleChange}
                disabled={!editMode}
              />
              <label>Email:</label>
              <input
                type="email"
                name="email"
                value={user.email}
                onChange={handleChange}
                disabled={!editMode}
              />
              <label>Password:</label>
              <input
                type="password"
                name="upassword"
                value={user.upassword}
                onChange={handleChange}
                disabled={!editMode}
              />
              {editMode ? (
                <div className="save-cancel">
                <button onClick={handleSaveProfile}>Save</button>
                <button onClick={() => setEditMode(false)} className="cancel">Cancel</button>
              </div>
              ) : (
                <button onClick={() => setEditMode(true)}>Edit</button>
              )}
            </div>
          </div>
        </div>

        <div className="address-container">
        <div className="profile-title">ADDRESSES</div>
          {addresses.map((address, index) => (
            <div key={address.addressId} className="address-item">
              <span className="address-item-number">Address {index + 1}:</span>
              <p>{`${address.houseNumber}, ${address.addressline1}, ${address.addressline2}, ${address.city}, ${address.state} ${address.zipcode}`}</p>
              <div className="address-actions">
                <button onClick={() => openEditModal(address)} className="edit-btn">
                  Edit
                </button>
                <button onClick={() => handleDeleteAddress(address.addressId)} className="delete-btn">
                  Delete
                </button>
              </div>
            </div>
          ))}
          <button className="add-address-button" onClick={handleAddAddress}>
            Add Address
          </button>
        
      </div>

      {/* Address Modals */}
      <AddressAddModal
        isOpen={isAddModalOpen}
        onRequestClose={handleModalClose}
        onSave={handleAddAddressSave}
      />
      {selectedAddress && (
        <AddressEditModal
          isOpen={isEditModalOpen}
          onRequestClose={handleModalClose}
          address={selectedAddress}
          onSave={handleAddressSave}
        />
      )}
    </div>
  );
};

export default UserProfile;

