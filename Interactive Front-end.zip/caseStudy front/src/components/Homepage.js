// Homepage.jsx
import React from 'react';
import Navbar from './Navbar';

const Homepage = () => {
  return (
    <div>
      <div>Welcome to the homepage!</div>
      <Navbar />
      
     
    </div>
  );
};

export default Homepage;
