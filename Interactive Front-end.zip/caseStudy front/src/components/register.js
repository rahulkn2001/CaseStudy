import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import "./login.css";
import axios from 'axios';

const Login = () => {
  // State hooks for user input
  const [password, setPassword] = useState('12345');
  const [email, setemail] = useState('sudhanvagv44@gmail.com');
  const [firstname, setfirstname] = useState('sudhanva');
  const [lastname, setlastname] = useState('gv');
  
  // State hooks for error and success messages
  const [error, seterror] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  
  const navigate = useNavigate();

  // Handlers for input changes
  const handlePasswordChange = (e) => setPassword(e.target.value);
  const handleFirstnameChange = (e) => setfirstname(e.target.value);
  const handleLastnameChange = (e) => setlastname(e.target.value);
  const handleEmailChange = (e) => setemail(e.target.value);

  // Handler for form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Submitted:', { password, firstname, email, lastname });
    callApi(password, firstname, email, lastname);
  };

  // API call for registration
  async function callApi(password, firstname, email, lastname) {
    try {
      const response = await axios.post('https://localhost:7174/api/Register/register',
        { upassword: password, Firstname: firstname, Email: email, Lastname: lastname },
        { headers: { 'Content-Type': 'application/json' } }
      );

      setSuccessMessage('Registration successful. Please check your email for verification.');
      navigate('/');
    } catch (error) {
      seterror('Registration failed: ' + (error.response?.data || error.message));
    }
  }

  return (
    // <div>
    //   <div>Login</div>
      
    //   <form onSubmit={handleSubmit}>
    //     <label>
    //       Password
    //       <input
    //         type="password"
    //         name="password"
    //         value={password}
    //         onChange={handlePasswordChange}
    //       />
    //     </label>
    //     <br />
    //     <label>
    //       First name
    //       <input
    //         type="text"
    //         name="firstname"
    //         value={firstname}
    //         onChange={handleFirstnameChange}
    //       />
    //     </label>
    //     <br />
    //     <label>
    //       Last name
    //       <input
    //         type="text"
    //         name="lastname"
    //         value={lastname}
    //         onChange={handleLastnameChange}
    //       />
    //     </label>
    //     <br />
    //     <label>
    //       Email
    //       <input
    //         type="text"
    //         name="email"
    //         value={email}
    //         onChange={handleEmailChange}
    //       />
    //     </label>
    //     <br />
    //     <button type="submit">Submit</button>
    //   </form>
      
    //   {error && <div className="error">{error}</div>}
    //   {successMessage && <div className="success">{successMessage}</div>}
    // </div>
    <div className='register-container'>

    <form className="register-form" onSubmit={handleSubmit}>
    <div className="form-group">
        <label htmlFor="email">Email:</label>
        <input
            type="email"
            id="Email"
            // value={Email}
            // onChange={(e) => setEmail(e.target.value)}
            required
        />
    </div>
    <div className="form-group">
        <label htmlFor="password">Password:</label>
        <input
            type="password"
            id="password"
            // value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
        />
    </div>
    <button type="submit" className="login-button">Log In</button>
</form>
</div>

  );
};

export default Login;
